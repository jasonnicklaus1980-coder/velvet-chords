# Velvet Keys 1.0.0

A split Smart keyboard and chord-pad plugin for MPC OS. It grew out of Velvet Chords 1.0 and installs beside it as a separate plugin. Each pad plays a full chord, sent out as MIDI to whatever instrument you choose, with song sections, a split Smart keyboard, a Smart Scale mode, an R&B chord kit and 64 editable custom pads. This build has no sounds of its own: it always plays another track's instrument.

It is a native MPC OS plugin (VST2 `.so`) loaded by MPC's built-in plugin host, installed the same way as community plugins such as the JV-880 port.

## Install (official Akai SDK format, no root)

Velvet Keys needs **MPC OS 3.10.1 or later**. There is no installer script and nothing on the MPC's system is changed.

1. Unzip `VelvetKeys-SDK-<version>.zip` and copy the folder `Velvet - VST - Velvet Keys` into a folder named exactly `VST2 Plugins` at the top of a USB stick, an SD card, an SSD or the MPC's internal drive.
2. On the MPC: **Preferences > Enhancements (Beta)**, turn on **Enable Enhancements** and **External Plugin Support**.
3. Make a plugin track and choose **External Plugins > Velvet Keys**.

The zip holds a 32-bit build (MPC X, Live, Live II, One, One+, Key 37/61, Force) and a 64-bit build (MPC Live III, MPC XL), the screen skin, and `SDK-CHECKS.txt`: the results of Akai's own validator and MPC host simulator for that build.

**Velvet Keys and Velvet Chords are separate plugins.** Velvet Keys has its own name, its own id, its own MIDI port (*Velvet Keys Out*) and its own data folder (`Velvet Keys` on the internal drive), so installing or removing it never touches a Velvet Chords you already have. Projects made with one do not load in the other.

Akai's host throws away MIDI that a plugin sends back to it, so *To MPC* does nothing on this route: Velvet Keys reaches other tracks through **Velvet Keys Out** (the default).

To remove it, delete the folder from `VST2 Plugins`.

## First use

1. Make a new plugin track and choose **Velvet Keys** from the plugin browser (instrument plugins).
2. Hit pad A01. If you hear nothing, open the plugin's parameters, turn **Learn pad 1** on, and hit the pad you want as pad 1. Pads 2-64 follow from there (16 per bank, banks A-D).
3. Pick a **Mode**: Song, Smart scale, R&B kit, Chord types or Custom.

## The screen

The plugin comes with its own MPC screen skin, five pages on the function keys:

- **Play**: mode buttons, song and section pickers with the song's data status, Smart Scale controls, 16 chord keys showing each pad's chord and function (the key you last played lights up; tap a key to hear it), the bank buttons A-D, a one-octave keyboard for the key with dots on the notes of the scale, the scale picker, and a readout of the exact notes playing.
- **Perform**: the two split keyboards (chords on the left, notes that fit on the right, black keys labelled with their jobs), play from, split point, bank, key, what the right hand plays, velocity curve, strum, arpeggiator, voicing, inversion, octave, transpose, voice leading, MIDI out, pad 1 note with Learn, and Export MIDI.
- **Pattern**: rhythm presets, the 16-step grid, swing, note length and timing, plus MIDI output settings.
- **Edit**: tap a chord key to pick it, then set its root on the keyboard, its bass note, chord type, inversion and octave. Copy to Custom starts you from whatever layout you were playing.

The Q-Links follow the page. If the skin doesn't appear (for example `/sdcard/Synths` isn't in MPC's content locations; the installer warns about this), the plugin still works through MPC's generic parameter view.

## Using it like ChordPrism: chords and patterns into any instrument

Velvet Keys is a chord-and-pattern generator that plays **another** instrument, the way ChordPrism sits in front of a synth in a DAW. It sends its chords out as MIDI and makes no sound itself.

1. **Track 1: Velvet Keys.** *Send chords as MIDI to* is **Virtual port** from the start (Pattern page). Output is on channel 16 by default.
2. **Track 2: your instrument.** Any keygroup or plugin track: an MPC piano, an AIR synth, a Rhodes. In that track's MIDI input settings, choose the input port **Velvet Keys Out**, channel 16, with monitoring on so it plays while Track 1 is selected. (Menu names differ between MPC OS versions.)
3. Select Track 1 and play the pads. Each pad sends its chord, or its rhythm pattern, to Track 2.

The *MIDI port* readout on the Pattern page shows whether the port opened. If MPC doesn't list *Velvet Keys Out* as an input, save the project, then reload it or restart MPC with the plugin loaded so MPC rescans its MIDI ports.

While the port is on, the plugin ignores notes arriving on its own output channel, so a track set to "all inputs" can't loop chords back into it.

*To MPC* sends the same MIDI to MPC through the plugin interface instead. Whether MPC forwards that anywhere is untested; *Both* uses both routes.

## The split keyboard

For a MIDI keyboard plugged into the MPC. On the **Perform** page set **Play from** to **Split keyboard**:

- **Left of the split: chords.** Every white key plays one pad's chord from the bank on screen. The two octaves under the split are pads 1 to 14, left to right; the two white keys below those are pads 15 and 16. Strum, arp, patterns, Hold and Repeat work as they do on the pads.
- **From the split up: notes that fit.** Every white key plays one note that fits the chord you last played with your left hand. **Right hand plays** chooses which: *Chord tones* (only notes of the chord, the split key is its root), *Scale* (the chord plus the key's scale) or *Bass* (chord tones two octaves down). *Right hand octave* moves them.
- **Left-hand black keys are shifters.** In every octave: C# and D# move the key down and up, F# and G# pick the previous and next scale, A# moves to the next bank. In Song mode, where there is no key or scale to pick, C#/D# move Transpose and F#/G# the song section. They send no notes.
- **Right-hand black keys are one-finger generators.** Hold one and it plays over the current chord until you let go. Out of the box: C# arpeggio up, D# arpeggio down, F# up and down, G# a simple melody, A# a busy melody. They follow the chord as you change it, and the same key an octave higher plays an octave higher.
- **Each of those five keys has its own settings.** On the Perform page tap a black key on the right-hand keyboard to pick it (it shows its pattern), then set: **Pattern** (Arp up, Arp down, Up-down, Random, Stabs, Melody, Busy), **Rate** (1/4 to 1/32), **Range** (1 to 3 octaves), **Tones** (all chord tones, triad, or root and fifth) and **Length** (how long each note lasts). The settings are saved with the project.
- **On the screen** the Perform page shows both hands as two keyboards of the same size. The left one shows the chord on each of the first seven white keys (tap a key to hear it; tap a black key to use that shifter). The right one shows the note each white key plays right now and the pattern on each black key.
- **Split at** moves the split (C1 to C5). The default is C3, note 60.

While the split keyboard is on, the MPC's own pads are read as keys too, so use the keyboard, or switch back to **Pads only** for the pads. Tapping a pad on the screen always plays that pad. On a second copy set to Smart pads **Follow**, the right hand follows the chords of the first copy.

## Rendering and bouncing

The plugin makes no audio, so its own track bounces as silence. To get the chords into a render, record them onto the instrument's track first: arm the instrument track (the one listening to *Velvet Keys Out*), record while you play Velvet Keys, then bounce or export that track. The **Export MIDI** button is the other route: it saves the section as a `.mid` you can load onto any track.

## Smart Scale pads

Set **Smart Scale pads** (Play page) to **Pads 9-16** and the bottom row of every bank stops playing chords and plays single notes that fit the chord you last played on the top row. Play a chord with your left hand and a melody, bassline or riff with your right, and nothing clashes. The keys on screen show each note and what it is (root, 3rd, 5th, b7...), and they relabel the moment you change chords.

**Smart notes** chooses what those pads play:
- **Chord**: only the chord's notes, rising across two octaves.
- **Scale**: the chord's notes plus the rest of the key's scale (the song's key in Song mode), for melodies with passing notes.
- **Bass**: the chord's notes down in the bass register, starting on the slash-bass note for chords like Fmaj7/G.

*Smart octave* (a Q-Link on the Play page) moves them up or down.

### Two instances: chords on one, bass or melody on the other

Load Velvet Keys on two tracks. On the second, set **Smart pads** to **Follow**: all of its pads become Smart notes that follow whatever chord the *first* instance is playing, live. Set the second to **Bass** for a bassline that always matches, or **Scale** for a lead. Give each its own sound, or route each to a different instrument with the virtual port and different output channels. Instances share the chord directly inside MPC, so no MIDI routing is needed between them.

## The Tools page

- **Hold:** tap a pad and its chord keeps playing. Another pad replaces it; the same pad again stops it.
- **Repeat:** the playing chord retriggers in time with the MPC (1/4 to 1/32). A Pattern, if one is chosen, takes priority.
- **Melody generator:** while a chord plays, a melody runs above it: chord notes on the strong beats, scale notes in between, moving mostly in steps. *Simple* leaves more space, *Busy* plays more notes. It follows the MPC's song position like patterns do.
- **Key and scale: follow another copy:** with two copies of Velvet Keys, turn this on in the second one and it takes the first one's key and scale whenever you change them there. (Smart pads → Follow makes it follow the chords too.)
- **MIDI import:** copy `.mid` files into the **Velvet Keys/Import** folder on the MPC's internal drive (the plugin creates it). Pick a file and press **Load chords**: notes that start together become a chord, each chord is named (slash chords from the lowest note), and they're laid out on the pads in order with the file's exact notes (up to 64 chords, banks A–D). Drum tracks are ignored. **Pads play → Layout** goes back to your normal pads; imported chords are saved with your project. Use **Copy to Custom** on the Edit page to change them.

## The Pattern page

Pick a rhythm and every pad you hold plays its chord in that rhythm instead of a single hit. There are 15 presets (Sustain, Quarters, Neo-soul push, Slow jam, Gospel drive, Funk 16ths, Bass and stabs, Reggae skank, Caribbean 3-3-2, Dancehall, Afrobeats, Half-time and more).

The grid shows the 16 steps. Tap a cell to set what a step does: **Accent** or **Chord** plays the whole chord (accent louder), **Upper** / **Upper acc** plays only the notes above the bass, **Bass** plays only the bass note, **Tie** holds the previous step, and **Rest** is silence. Editing a preset saves it as your Custom pattern. On this page the 16 Q-Links edit the 16 steps.

**Step length** sets the grid (1/8 to 1/32, with triplets), **Swing** pushes every second step late, and **Note length** shortens each hit. **Timing: Follow MPC** locks the pattern to the MPC's song position while the sequencer runs. **Free** starts the pattern from the moment you hit the pad. The pattern takes priority over the arpeggiator.

## Parameters

| Parameter | What it does |
|---|---|
| Mode | Song, Smart scale, R&B kit, Chord types, Custom |
| Song | Song for Song mode |
| Section | Section on bank A; banks B-D get the following sections |
| Key, Scale | Key and scale for Smart scale, R&B kit and Chord types (17 scales) |
| Transpose | Shifts Song mode by -12 to +12 semitones; the song's original key stays in the data |
| Voicing | Bass + upper (default), Close, Drop 2, Spread, Upper only |
| Inversion, Octave | Global chord inversion and register |
| Voice lead | Pads in a bank are voiced to move smoothly from pad to pad |
| Strum, Strum dir | Delay between chord notes (0-150 ms), up/down/alternate |
| Arp, Arp rate | Arpeggiator (up, down, up-down, random), synced to the MPC tempo |
| Velocity | Linear, soft, hard or fixed response |
| Keyboard, Split point | *Pads only* (every note is a pad) or *Split keyboard*, and the key where the right hand starts (default C3, note 60). See "The split keyboard" |
| Pad 1 note, Learn pad 1 | Which incoming note is pad A01 (pads 2-64 follow in order) |
| Learn all 16 pads | If the pads come out in the wrong order: press it, then hit MPC pads 1 to 16 in order. Velvet Keys remembers each pad's note (banks B-D follow) and saves it with the project. Make sure the MPC's own PAD PERFORM is off on this track first, because it changes which notes the pads send |
| MIDI out | Virtual port (*Velvet Keys Out*, the default), To MPC (plugin MIDI output, routing untested), or both |
| MIDI channel | Output channel (default 16) |
| Pattern, Step length, Swing, Note length, Timing, Step 1-16 | Pattern generator (see above) |
| Smart pads, Smart notes, Smart octave | Smart Scale pads and instance following (see above) |
| Edit pad / root / type / bass / inversion / octave | Edit a custom pad. Editing switches Mode to Custom |
| Edit follows pad | In Custom mode, hitting a pad selects it for editing |
| Copy to Custom | Copies the current layout into the custom pads so you can tweak it |
| Export MIDI | Saves the current section (or bank) as `.mid` and `.progression` in the `Velvet Keys` folder |
| Now playing | Last pad: chord, function and exact notes |
| Info | Song data status and confidence, or the scale's notes |

Custom pads, edits and settings are saved inside the MPC project.

## Song data

None of the songs is marked verified. Every entry is labeled `unverified-analysis` with a confidence level: the chord functions are well known, but extensions, bar placement and exact keys still need checking against the recordings. Pad voicings are generated performance voicings, not transcriptions of the records. To correct or add songs, edit `data/songs.json` in the source and rebuild.
