#!/bin/sh
# Package Velvet Chords in the official Akai MPC Plugin SDK format (github.com/inmusic-software/mpc-plugin-builder-sdk):
#   dist/sdk/Velvet Chords - VST - Velvet Chords/{plugin.json, version.xml, VST/*.so, Plugin Skins/}
#   dist/VelvetChords-SDK-<version>.zip   -> unzip, copy the folder into "VST2 Plugins" on a drive. No root needed.
# Needs build/arm/velvetchords.so (32-bit: MPC X, Live, Live II, One, One+, Key 37/61, Force). If zig is on the PATH
# it also builds the 64-bit one (MPC Live III, MPC XL) and re-links the 32-bit one so that VSTPluginMain is the only
# exported symbol, as the SDK asks. If the SDK can be fetched, its validator and MPC host simulator run too.
set -e
VER="${1:-1.0.0}"
NAME="Velvet Chords"; MAKER="Velvet Chords"; SLUG="velvet-chords"
FOLDER="$MAKER - VST - $NAME"
OUT="dist/sdk/$FOLDER"
[ -f build/arm/velvetchords.so ] || { echo "build/arm/velvetchords.so missing: build the ARM plugin first"; exit 1; }
rm -rf dist/sdk && mkdir -p "$OUT/VST" "$OUT/Plugin Skins"
CFLAGS="-std=gnu99 -O2 -fPIC -fvisibility=hidden -fno-strict-aliasing -shared"
LDF="-Wl,-z,defs -Wl,--version-script=scripts/sdk_exports.map -ldl -s"
HAVE64=0
if command -v zig >/dev/null 2>&1; then
  mkdir -p build/sdk
  # the targets the SDK documents: glibc 2.31, Cortex-A17 (32-bit MPCs) and Cortex-A55 (64-bit MPCs)
  if zig cc -target arm-linux-gnueabihf.2.31 -mcpu=cortex_a17 $CFLAGS -o "build/sdk/$SLUG-arm32.so" src/*.c $LDF; then
    cp "build/sdk/$SLUG-arm32.so" "$OUT/VST/$SLUG-arm32.so"
  fi
  if zig cc -target aarch64-linux-gnu.2.31 -mcpu=cortex_a55 $CFLAGS -o "build/sdk/$SLUG-arm64.so" src/*.c $LDF; then
    cp "build/sdk/$SLUG-arm64.so" "$OUT/VST/$SLUG-arm64.so"; HAVE64=1
  fi
fi
[ -f "$OUT/VST/$SLUG-arm32.so" ] || cp build/arm/velvetchords.so "$OUT/VST/$SLUG-arm32.so"
cp -r "package/skin/$FOLDER/." "$OUT/Plugin Skins/"
printf '<?xml version="1.0" encoding="utf-8"?>\n<plugincontent version="1.0">\n    <version>%s.0</version>\n    <uiversion>0.1.0.0</uiversion>\n</plugincontent>\n' "$VER" > "$OUT/version.xml"
{
  printf '{\n  "name": "%s",\n  "manufacturer": "%s",\n  "version": "%s",\n  "format": "vst2",\n  "kind": "instrument",\n' "$NAME" "$MAKER" "$VER"
  printf '  "uid": "VlvC",\n  "category": "Chords",\n  "numInputs": 0,\n  "numOutputs": 2,\n'
  printf '  "file32": "VST/%s-arm32.so",\n' "$SLUG"
  if [ "$HAVE64" = 1 ]; then printf '  "file64": "VST/%s-arm64.so",\n' "$SLUG"; fi
  printf '  "description": "Chord pads and a split Smart keyboard that play other tracks through the Velvet Chords Out MIDI port. Makes no sound of its own.",\n  "license": "MIT"\n}\n'
} > "$OUT/plugin.json"
{
  echo "Velvet Chords $VER for Akai MPC (official MPC Plugin SDK format)"
  echo
  echo "Needs MPC OS 3.10.1 or later. No root and no installer script."
  echo
  echo "1. Copy the folder \"$FOLDER\" into a folder named exactly \"VST2 Plugins\" at the top of a USB stick,"
  echo "   an SD card or the MPC's internal drive (make the folder if it is not there)."
  echo "2. On the MPC: Preferences > Enhancements (Beta): turn on Enable Enhancements and External Plugin Support."
  echo "3. Make a plugin track and pick External Plugins > Velvet Chords."
  echo "4. Velvet Chords makes no sound. It sends its chords to a MIDI port called \"Velvet Chords Out\": on the track"
  echo "   of the instrument you want to hear, choose that port as the MIDI input (channel 16) and switch monitoring on."
  echo
  echo "To remove it, delete the folder from \"VST2 Plugins\"."
  echo "Third-party plugins run inside the MPC without protection: save your project before trying a new one."
} > dist/sdk/INSTALL.txt
# optional checks with the SDK's own tools (skipped when the SDK cannot be fetched)
SDK="${MPC_SDK:-build/mpc-sdk}"
if [ ! -f "$SDK/tools/validate.py" ] && command -v git >/dev/null 2>&1; then
  git clone -q --depth 1 https://github.com/inmusic-software/mpc-plugin-builder-sdk "$SDK" 2>/dev/null || true
fi
VFAIL=""
if [ -f "$SDK/tools/validate.py" ] && command -v python3 >/dev/null 2>&1; then
  REPORT=dist/sdk/SDK-CHECKS.txt
  : > "$REPORT"
  HS=build/sdk_host_sim
  if [ -f build/native/velvetchords.so ] && command -v c++ >/dev/null 2>&1 && c++ -std=c++17 -O2 -o "$HS" "$SDK/tools/host-sim/host_sim.cpp" -ldl 2>/dev/null; then
    "$HS" build/native/velvetchords.so dump > dist/sdk/params.json 2>/dev/null || rm -f dist/sdk/params.json
    echo "== MPC host simulator (native build) ==" >> "$REPORT"
    "$HS" build/native/velvetchords.so test --seconds 2 --notes 36,38,40 2>&1 | grep -E "^(PASS|WARN|FAIL|Result)" >> "$REPORT" || true
    if grep -q "^FAIL" "$REPORT"; then cat "$REPORT"; echo "the SDK's MPC host simulator reported a failure"; exit 1; fi
  fi
  echo "== SDK validator ==" >> "$REPORT"
  if [ -f dist/sdk/params.json ]; then
    python3 "$SDK/tools/validate.py" "$OUT" --params dist/sdk/params.json >> "$REPORT" 2>&1 || VFAIL=1
  else
    python3 "$SDK/tools/validate.py" "$OUT" >> "$REPORT" 2>&1 || VFAIL=1
  fi
  rm -f dist/sdk/params.json
  cat "$REPORT"
  if [ -n "$VFAIL" ]; then echo "the SDK validator reported errors"; exit 1; fi
else
  echo "SDK tools not available: packaged without running the SDK validator"
fi
(cd dist/sdk && rm -f "../VelvetChords-SDK-$VER.zip" && zip -qr "../VelvetChords-SDK-$VER.zip" .)
echo "dist/VelvetChords-SDK-$VER.zip"
