#include "../src/engine.h"
#include "../src/export.h"
#include "../src/vcmath.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { checks++; if (!(cond)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static int pcm(int x) { x %= 12; return x < 0 ? x + 12 : x; }

static int mask_of_notes(const char *spelled) { /* "C Eb G Bb D" -> pitch-class mask */
    int m = 0;
    char buf[64];
    strncpy(buf, spelled, 63); buf[63] = 0;
    for (char *t = strtok(buf, " "); t; t = strtok(0, " ")) { int pc = vc_pc_parse(t, 0); if (pc >= 0) m |= 1 << pc; }
    return m;
}

static void test_qualities_against_spelled(void) {
    /* independent expectations, written as note names, for root C */
    static const char *EXP[][2] = {
        {"C", "C E G"}, {"Cm", "C Eb G"}, {"Cdim", "C Eb Gb"}, {"Caug", "C E G#"}, {"Csus2", "C D G"}, {"Csus4", "C F G"},
        {"C5", "C G"}, {"C6", "C E G A"}, {"Cm6", "C Eb G A"}, {"Cadd9", "C E G D"}, {"Cmadd9", "C Eb G D"}, {"C6/9", "C E G A D"},
        {"Cmaj7", "C E G B"}, {"Cm7", "C Eb G Bb"}, {"C7", "C E G Bb"}, {"Cdim7", "C Eb Gb A"}, {"Cm7b5", "C Eb Gb Bb"},
        {"Cmmaj7", "C Eb G B"}, {"C7sus4", "C F G Bb"}, {"Cmaj9", "C E G B D"}, {"Cm9", "C Eb G Bb D"}, {"C9", "C E G Bb D"},
        {"C9sus4", "C F G Bb D"}, {"C11", "C G Bb D F"}, {"Cm11", "C Eb G Bb D F"}, {"Cmaj7#11", "C E G B F#"},
        {"C13", "C E Bb D A"}, {"Cm13", "C Eb Bb D A"}, {"Cmaj13", "C E B D A"}, {"C7b9", "C E G Bb Db"}, {"C7#9", "C E G Bb D#"},
        {"C7#5", "C E G# Bb"}, {"C7b5", "C E Gb Bb"}, {"C9#11", "C E Bb D F#"}, {"C13b9", "C E Bb Db A"}, {"C7alt", "C E Bb D# Ab"},
        {"Cmmaj9", "C Eb G B D"}, {"Cm6/9", "C Eb G A D"}, {"Cmaj7#5", "C E G# B"}, {"C7sus2", "C D G Bb"},
        /* aliases */
        {"CM7", "C E G B"}, {"C-7", "C Eb G Bb"}, {"Cmin9", "C Eb G Bb D"}, {"C\xc3\xb8", "C Eb Gb Bb"}, {"Co7", "C Eb Gb A"},
        {"C7(#9)", "C E G Bb D#"}, {"Cm(maj7)", "C Eb G B"}, {"C69", "C E G A D"}, {"Csus", "C F G"}, {"C+", "C E G#"},
    };
    int n = (int)(sizeof(EXP) / sizeof(EXP[0]));
    CHECK(n - 10 == VC_NUM_QUALITIES, "every quality needs a spelled expectation (%d vs %d)", n - 10, VC_NUM_QUALITIES);
    for (int i = 0; i < n; i++) {
        ChordSpec c;
        int ok = vc_chord_parse(EXP[i][0], &c);
        CHECK(ok, "parse %s", EXP[i][0]);
        if (!ok) continue;
        CHECK(vc_chord_pcmask(&c) == mask_of_notes(EXP[i][1]), "%s pitch classes (got mask %x)", EXP[i][0], vc_chord_pcmask(&c));
    }
}

static void test_parse(void) {
    ChordSpec c;
    CHECK(vc_chord_parse("G#m/F#", &c) && c.root == 8 && c.bass == 6 && !strcmp(VC_QUALITIES[c.quality].suffix, "m"), "G#m/F#");
    CHECK(vc_chord_parse("A/F#", &c) && c.root == 9 && c.bass == 6, "A/F#");
    CHECK(vc_chord_parse("C6/9", &c) && c.bass == -1 && !strcmp(VC_QUALITIES[c.quality].suffix, "6/9"), "6/9 is not a slash chord");
    CHECK(vc_chord_parse("C6/9/E", &c) && c.bass == 4, "6/9 over E");
    CHECK(vc_chord_parse("Dbmaj7", &c) && c.root == 1, "Dbmaj7");
    CHECK(vc_chord_parse("C/C", &c) && c.bass == -1, "C/C has no separate bass");
    CHECK(!vc_chord_parse("H7", &c), "reject H7");
    CHECK(!vc_chord_parse("Cxyz", &c), "reject unknown suffix");
    CHECK(!vc_chord_parse("C/X", &c), "reject bad bass");
    char buf[32];
    vc_chord_parse("Ebm7b5/A", &c);
    vc_chord_name(&c, 1, buf, sizeof(buf));
    CHECK(!strcmp(buf, "Ebm7b5/A"), "name round trip (%s)", buf);
}

static void test_voicings(void) {
    int total = 0;
    for (int q = 0; q < VC_NUM_QUALITIES; q++)
        for (int root = 0; root < 12; root++)
            for (int bass = -1; bass < 12; bass += 4) /* -1, 3, 7, 11 */
                for (int style = 0; style < VC_VOICE_COUNT; style++)
                    for (int inv = 0; inv < 4; inv++)
                        for (int oct = -2; oct <= 2; oct++) {
                            ChordSpec c;
                            memset(&c, 0, sizeof(c));
                            c.root = root; c.quality = q; c.bass = (bass == root) ? -1 : bass;
                            Voicing v;
                            vc_voice(&c, style, inv, oct, 0, &v);
                            total++;
                            int m = 0, ok = 1;
                            for (int i = 0; i < v.n; i++) { m |= 1 << pcm(v.notes[i]); if (i && v.notes[i] <= v.notes[i - 1]) ok = 0; }
                            int want = vc_chord_pcmask(&c);
                            if (style == VC_VOICE_UPPER_ONLY && c.bass >= 0) want &= ~(1 << c.bass) | vc_chord_pcmask(&(ChordSpec){.root = root, .quality = q, .bass = -1});
                            CHECK(ok, "ascending unique q=%s root=%d style=%d", VC_QUALITIES[q].suffix, root, style);
                            CHECK(m == want, "pitch classes q=%s root=%d bass=%d style=%d inv=%d oct=%d (got %x want %x)",
                                  VC_QUALITIES[q].suffix, root, c.bass, style, inv, oct, m, want);
                            if (c.bass >= 0 && style != VC_VOICE_UPPER_ONLY)
                                CHECK(pcm(v.notes[0]) == c.bass, "slash bass lowest q=%s root=%d bass=%d style=%d", VC_QUALITIES[q].suffix, root, c.bass, style);
                            if ((style == VC_VOICE_BASS_UPPER || style == VC_VOICE_SPREAD) && c.bass < 0)
                                CHECK(pcm(v.notes[0]) == root && v.has_bass, "root in bass style=%d", style);
                            CHECK(v.notes[0] >= 0 && v.notes[v.n - 1] <= 127, "range");
                        }
    printf("  voiced %d chord/voicing combinations\n", total);

    /* inversions of a close triad: bass note changes C -> E -> G */
    ChordSpec c;
    vc_chord_parse("C", &c);
    Voicing v;
    int expect[3] = {0, 4, 7};
    for (int inv = 0; inv < 3; inv++) {
        vc_voice(&c, VC_VOICE_CLOSE, inv, 0, 0, &v);
        CHECK(pcm(v.notes[0]) == expect[inv], "close inversion %d bass", inv);
    }
    /* drop 2 of Cmaj7 root position: C3 E3 G3 B3 -> G2 C3 E3 B3 */
    vc_chord_parse("Cmaj7", &c);
    vc_voice(&c, VC_VOICE_DROP2, 0, 0, 0, &v);
    CHECK(v.n == 4 && v.notes[0] == 43 && v.notes[1] == 48 && v.notes[2] == 52 && v.notes[3] == 59, "drop2 Cmaj7 (%d %d %d %d)", v.notes[0], v.notes[1], v.notes[2], v.notes[3]);
    /* bass+upper Fm9: F1 bass, rootless Ab C Eb G around the middle */
    vc_chord_parse("Fm9", &c);
    vc_voice(&c, VC_VOICE_BASS_UPPER, 0, 0, 0, &v);
    CHECK(v.n == 5 && v.notes[0] == 41, "Fm9 bass F (got %d notes, bass %d)", v.n, v.notes[0]);

    /* transposition preserves interval structure */
    for (int q = 0; q < VC_NUM_QUALITIES; q++) {
        ChordSpec a = {0}, b;
        a.quality = q; a.bass = -1;
        Voicing va, vb;
        vc_voice(&a, VC_VOICE_CLOSE, 0, 0, 0, &va);
        for (int t = 1; t < 12; t++) {
            b = vc_chord_transpose(&a, t);
            vc_voice(&b, VC_VOICE_CLOSE, 0, 0, 0, &vb);
            int same = va.n == vb.n;
            for (int i = 0; same && i < va.n; i++) same = (vb.notes[i] - va.notes[i]) == t;
            CHECK(same, "transpose %s by %d keeps shape", VC_QUALITIES[q].suffix, t);
        }
    }

    /* voice leading keeps neighbouring chords close */
    const char *prog[4] = {"Dbmaj7", "C7", "Fm7", "Ebm7"};
    Voicing prev, cur;
    int have = 0, maxmove = 0;
    for (int i = 0; i < 4; i++) {
        vc_chord_parse(prog[i], &c);
        vc_voice(&c, VC_VOICE_BASS_UPPER, 0, 0, have ? &prev : 0, &cur);
        if (have) {
            int top_move = abs((int)cur.notes[cur.n - 1] - (int)prev.notes[prev.n - 1]);
            if (top_move > maxmove) maxmove = top_move;
        }
        prev = cur; have = 1;
    }
    CHECK(maxmove <= 5, "voice-led top voice moves at most a 4th (moved %d)", maxmove);
}

static void test_songs(void) {
    for (int s = 0; s < VC_NUM_SONGS; s++) {
        const Song *so = &VC_SONGS[s];
        CHECK(so->nsections > 0, "%s has sections", so->title);
        CHECK(strcmp(so->status, "verified") != 0, "%s: nothing in the starter set is marked verified", so->title);
        CHECK(!strcmp(so->confidence, "high") || !strcmp(so->confidence, "medium") || !strcmp(so->confidence, "low"), "confidence");
        CHECK(!strcmp(so->status, "original") ? so->year == 0 && so->bpm > 0 : (so->year >= 1960 && so->year <= 2019), "%s year in range (originals: no year, own tempo)", so->title);
        for (int t = 0; t < s; t++) CHECK(strcmp(VC_SONGS[t].id, so->id), "duplicate id %s", so->id);
        float bar = so->ts_num * 4.f / so->ts_den;
        for (int k = 0; k < so->nsections; k++) {
            const SongSection *sec = &so->sections[k];
            float total = 0;
            for (int e = 0; e < sec->nev; e++) {
                ChordSpec c;
                CHECK(vc_chord_parse(sec->ev[e].chord, &c), "%s / %s: chord '%s' parses", so->title, sec->name, sec->ev[e].chord);
                total += sec->ev[e].beats;
            }
            float bars = total / bar;
            CHECK(bars == (float)(int)bars, "%s / %s: whole bars (%.2f)", so->title, sec->name, bars);
        }
    }
    int seen_original = 0;
    for (int s = 0; s < VC_NUM_SONGS; s++) { /* real songs first, so saved projects keep their song numbers */
        int orig = !strcmp(VC_SONGS[s].status, "original");
        CHECK(!(seen_original && !orig), "real songs listed before originals");
        seen_original |= orig;
    }
    printf("  %d songs checked\n", VC_NUM_SONGS);
}

static void test_layouts(void) {
    LayoutParams lp;
    memset(&lp, 0, sizeof(lp));
    static PadChord pads[VC_PADS];
    static Voicing v[VC_PADS];
    CustomPad custom[VC_PADS];
    memset(custom, 0, sizeof(custom));
    lp.mode = VC_MODE_KEY; lp.key = 0; lp.scale = 0;
    vc_build_pads(&lp, custom, pads);
    const char *cmaj[7] = {"Cmaj7", "Dm7", "Em7", "Fmaj7", "G7", "Am7", "Bm7b5"};
    for (int i = 0; i < 7; i++) CHECK(!strcmp(pads[i].name, cmaj[i]), "C major diatonic pad %d = %s (got %s)", i + 1, cmaj[i], pads[i].name);
    CHECK(!strcmp(pads[8].name, "Cmaj9") && !strcmp(pads[9].name, "Dm9"), "C major 9ths (%s %s)", pads[8].name, pads[9].name);
    CHECK(!strcmp(pads[0].roman, "Imaj7") && !strcmp(pads[1].roman, "ii7"), "roman numerals (%s %s)", pads[0].roman, pads[1].roman);
    CHECK(!strcmp(pads[24].name, "A7") && !strcmp(pads[24].roman, "V7/ii"), "secondary dominant V7/ii (%s %s)", pads[24].name, pads[24].roman);
    lp.key = 9; lp.scale = 2; /* A harmonic minor */
    vc_build_pads(&lp, custom, pads);
    CHECK(!strcmp(pads[4].name, "E7"), "A harmonic minor V7 = E7 (got %s)", pads[4].name);
    CHECK(!strcmp(pads[0].name, "Ammaj7"), "A harmonic minor i = Ammaj7 (got %s)", pads[0].name);
    for (int sc = 0; sc < VC_NUM_SCALES; sc++)
        for (int key = 0; key < 12; key++) {
            lp.scale = sc; lp.key = key;
            vc_build_pads(&lp, custom, pads);
            vc_voice_pads(&lp, pads, v);
            const Scale *S = &VC_SCALES[sc];
            int smask = 0;
            for (int j = 0; j < S->n; j++) smask |= 1 << pcm(key + S->iv[j]);
            for (int p = 0; p < 16; p++) if (pads[p].valid) CHECK((vc_chord_pcmask(&pads[p].spec) & ~smask) == 0, "scale %s key %d pad %d stays in scale", S->name, key, p);
        }
    /* song mode maps sections to banks, collapses repeats */
    for (int s = 0; s < VC_NUM_SONGS; s++) {
        lp.mode = VC_MODE_SONG; lp.song = s; lp.section = 0; lp.transpose = 0;
        vc_build_pads(&lp, custom, pads);
        CHECK(pads[0].valid, "%s bank A pad 1", VC_SONGS[s].title);
        if (VC_SONGS[s].nsections > 1) CHECK(pads[16].valid, "%s second section on bank B", VC_SONGS[s].title);
        lp.transpose = 3;
        static PadChord tp[VC_PADS];
        vc_build_pads(&lp, custom, tp);
        for (int p = 0; p < VC_PADS; p++) if (pads[p].valid) {
            CHECK(tp[p].spec.quality == pads[p].spec.quality && tp[p].spec.root == pcm(pads[p].spec.root + 3), "transposed pad keeps quality");
        }
    }
    /* Just the Two of Us pads */
    for (int s = 0; s < VC_NUM_SONGS; s++) if (!strcmp(VC_SONGS[s].id, "just-the-two-of-us-1980")) {
        lp.song = s; lp.transpose = 0;
        vc_build_pads(&lp, custom, pads);
        const char *exp[5] = {"Dbmaj7", "C7", "Fm7", "Ebm7", "Ab7"};
        for (int i = 0; i < 5; i++) CHECK(!strcmp(pads[i].name, exp[i]), "JTTOU pad %d %s", i + 1, pads[i].name);
        CHECK(!pads[5].valid, "JTTOU pad 6 empty");
    }
}

/* ---- note handling ---- */

static int rendered_active(Engine *e) { return en_sounding(e); }

static void run(Engine *e, int blocks, int n, float *L, float *R) { for (int b = 0; b < blocks; b++) en_process(e, L, R, n); }

static void test_note_handling(void) {
    static Engine e;
    static float L[512], R[512];
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_RNB;
    e.midi_out = 1;
    e.dirty = 1;
    long ons[128] = {0}, offs[128] = {0};
    unsigned rng = 7;
    for (int iter = 0; iter < 4000; iter++) {
        int nev = 0;
        for (int k = 0; k < 6; k++) {
            rng = rng * 1103515245u + 12345u;
            int r = (int)(rng >> 8);
            int note = 30 + r % 80;
            int frame = (r >> 8) % 512;
            int kind = (r >> 3) % 10;
            if (kind < 5) en_push_midi(&e, frame, 0x90, (unsigned char)note, (unsigned char)(1 + (r >> 5) % 127));
            else if (kind < 9) en_push_midi(&e, frame, 0x80, (unsigned char)note, 0);
            else en_push_midi(&e, frame, 0xB0, 64, (r & 1) ? 127 : 0);
            nev++;
        }
        if (iter % 500 == 0) { e.arp = (iter / 500) % ARP_COUNT; e.strum_ms = (float)((iter / 500) % 3) * 40.f; e.strum_dir = (iter / 500) % STRUM_COUNT; }
        if (iter % 700 == 0) { e.lp.mode = (iter / 700) % VC_MODE_COUNT; e.dirty = 1; } /* bank/layout changes while playing */
        en_process(&e, L, R, 512);
        for (int i = 0; i < e.nout; i++) { if ((e.out[i].d[0] & 0xF0) == 0x90) ons[e.out[i].d[1]]++; else offs[e.out[i].d[1]]++; }
        e.nout = 0;
        for (int i = 0; i < 512; i++) CHECK(L[i] == L[i] && L[i] <= 1.f && L[i] >= -1.f, "finite audio");
        if (fails > 20) return;
    }
    /* release everything */
    for (int n = 0; n < 128; n++) en_push_midi(&e, 0, 0x80, (unsigned char)n, 0);
    en_push_midi(&e, 0, 0xB0, 64, 0);
    run(&e, 1, 512, L, R);
    for (int i = 0; i < e.nout; i++) { if ((e.out[i].d[0] & 0xF0) == 0x90) ons[e.out[i].d[1]]++; else offs[e.out[i].d[1]]++; }
    e.nout = 0;
    run(&e, 48000 * 12 / 512, 512, L, R); /* 12 s of release tails */
    CHECK(en_owner_count(&e) == 0, "no held owners after all note-offs (%d)", en_owner_count(&e));
    CHECK(e.nqueue == 0, "strum queue empty");
    CHECK(rendered_active(&e) == 0, "no notes left on (%d)", rendered_active(&e));
    int bal = 1;
    for (int n = 0; n < 128; n++) { if (ons[n] != offs[n] || e.out_ref[n]) { bal = 0; printf("  note %d on %ld off %ld ref %d\n", n, ons[n], offs[n], e.out_ref[n]); } }
    CHECK(bal, "MIDI out note-on/off balanced");

    /* retrigger the same pad without a note-off, then one note-off */
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_RNB; e.dirty = 1;
    en_push_midi(&e, 0, 0x90, 36, 100);
    en_push_midi(&e, 10, 0x90, 36, 100);
    en_push_midi(&e, 20, 0x80, 36, 0);
    run(&e, 1, 512, L, R);
    run(&e, 48000 * 6 / 512, 512, L, R);
    CHECK(en_owner_count(&e) == 0 && en_sounding(&e) == 0, "double note-on then one note-off leaves nothing stuck");

    /* sustain: chord keeps ringing after pad release until pedal up */
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_RNB; e.dirty = 1;
    en_push_midi(&e, 0, 0xB0, 64, 127);
    en_push_midi(&e, 0, 0x90, 36, 100);
    en_push_midi(&e, 100, 0x80, 36, 0);
    run(&e, 50, 512, L, R);
    CHECK(en_owner_count(&e) == 1, "sustained owner kept");
    en_push_midi(&e, 0, 0xB0, 64, 0);
    run(&e, 48000 * 8 / 512, 512, L, R);
    CHECK(en_owner_count(&e) == 0 && en_sounding(&e) == 0, "pedal up releases");

    /* strum timing: 50 ms at 48 kHz = 2400 samples per note */
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_TYPES; e.lp.voicing = VC_VOICE_CLOSE; e.dirty = 1;
    e.midi_out = 1; e.strum_ms = 50.f;
    en_push_midi(&e, 100, 0x90, 36 + 3, 100); /* Cmaj7, 4 notes */
    int64_t times[8]; int nt = 0;
    for (int b = 0; b < 40; b++) {
        int64_t t0 = e.now;
        en_process(&e, L, R, 512);
        for (int i = 0; i < e.nout; i++) if ((e.out[i].d[0] & 0xF0) == 0x90 && nt < 8) times[nt++] = t0 + e.out[i].frame;
        e.nout = 0;
    }
    CHECK(nt == 4, "strum played 4 notes (%d)", nt);
    for (int i = 1; i < nt; i++) CHECK(times[i] - times[i - 1] == 2400, "strum gap %d = %lld", i, (long long)(times[i] - times[i - 1]));

    /* arp timing: 120 bpm, 1/16 = 6000 samples at 48 kHz */
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_TYPES; e.dirty = 1;
    e.midi_out = 1; e.arp = ARP_UP; e.arp_rate = RATE_16; e.tempo = 120.0;
    en_push_midi(&e, 0, 0x90, 36 + 3, 100);
    nt = 0;
    for (int b = 0; b < 60; b++) {
        int64_t t0 = e.now;
        en_process(&e, L, R, 512);
        for (int i = 0; i < e.nout; i++) if ((e.out[i].d[0] & 0xF0) == 0x90 && nt < 8) times[nt++] = t0 + e.out[i].frame;
        e.nout = 0;
    }
    CHECK(nt >= 4, "arp produced steps (%d)", nt);
    for (int i = 1; i < nt; i++) CHECK(times[i] - times[i - 1] == 6000, "arp step %d = %lld", i, (long long)(times[i] - times[i - 1]));

    /* velocity carries through to the MIDI output */
    int vout[2] = {0, 0};
    for (int k = 0; k < 2; k++) {
        en_init(&e, 48000.f);
        e.lp.mode = VC_MODE_RNB; e.dirty = 1;
        en_push_midi(&e, 0, 0x90, 36, k ? 127 : 30);
        en_process(&e, L, R, 512);
        for (int i = 0; i < e.nout; i++) if ((e.out[i].d[0] & 0xF0) == 0x90) vout[k] = e.out[i].d[2];
    }
    CHECK(vout[1] > vout[0] * 2 && vout[0] > 0, "velocity 127 sends harder notes than 30 (%d vs %d)", vout[1], vout[0]);
}

/* ---- pattern generator ---- */
typedef struct { int64_t t; int note, on, vel; } Hit;

static int collect(Engine *e, int blocks, Hit *h, int max) {
    static float L[512], R[512];
    int n = 0;
    for (int b = 0; b < blocks; b++) {
        int64_t t0 = e->now;
        en_process(e, L, R, 512);
        for (int i = 0; i < e->nout && n < max; i++) {
            int on = (e->out[i].d[0] & 0xF0) == 0x90;
            h[n].t = t0 + e->out[i].frame; h[n].note = e->out[i].d[1]; h[n].on = on; h[n].vel = e->out[i].d[2]; n++;
        }
        e->nout = 0;
    }
    return n;
}

static Engine *pat_engine(const char *steps, double tempo, int rate) {
    static Engine e;
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_TYPES; e.lp.voicing = VC_VOICE_BASS_UPPER; e.dirty = 1;
    e.midi_out = 1; e.tempo = tempo; e.pat_rate = rate; e.pat_sync = 1; e.playing = 0;
    e.pattern_on = 1; e.gate = 1.0f;
    memcpy(e.pat, steps, EN_STEPS);
    return &e;
}

static void test_patterns(void) {
    static Hit h[4000];
    /* quarters at 120 bpm, 1/16 steps: one chord every 4 steps = 24000 samples */
    Engine *e = pat_engine("X---x---x---x---", 120.0, PRATE_16);
    en_push_midi(e, 100, 0x90, 36 + 3, 100); /* Cmaj7: C1 bass + upper */
    int n = collect(e, 220, h, 4000);
    int64_t ons[8]; int k = 0;
    int lowest = 999;
    for (int i = 0; i < n; i++) if (h[i].on && h[i].note < lowest) lowest = h[i].note;
    for (int i = 0; i < n && k < 8; i++) if (h[i].on && h[i].note == lowest) ons[k++] = h[i].t;
    CHECK(k >= 4, "quarter pattern repeats (%d)", k);
    for (int i = 1; i < k; i++) CHECK(ons[i] - ons[i - 1] == 24000, "quarter spacing %lld", (long long)(ons[i] - ons[i - 1]));
    CHECK(ons[0] == 100, "first chord at the press (%lld)", (long long)ons[0]);
    /* accent: first (X) louder than second (x) */
    int v1 = -1, v2 = -1;
    for (int i = 0; i < n; i++) if (h[i].on && h[i].note == lowest) { if (v1 < 0) v1 = h[i].vel; else if (v2 < 0) v2 = h[i].vel; }
    CHECK(v1 > v2 && v2 > 0, "accent louder (%d vs %d)", v1, v2);

    /* ties and gate: X--- with gate 50%% holds 2 steps = 12000 samples */
    e = pat_engine("X---............", 120.0, PRATE_16);
    e->gate = 0.5f;
    en_push_midi(e, 0, 0x90, 36 + 3, 100);
    n = collect(e, 40, h, 4000);
    int64_t on_t = -1, off_t = -1;
    for (int i = 0; i < n; i++) { if (h[i].on && on_t < 0) on_t = h[i].t; if (!h[i].on && off_t < 0) off_t = h[i].t; }
    CHECK(off_t - on_t == 12000, "tie + 50%% gate = 2 steps (%lld)", (long long)(off_t - on_t));

    /* swing 50%%: odd 16ths late by a quarter step (1500 samples at 120 bpm) */
    e = pat_engine("xxxxxxxxxxxxxxxx", 120.0, PRATE_16);
    e->swing = 0.5f;
    en_push_midi(e, 0, 0x90, 36 + 3, 100);
    n = collect(e, 60, h, 4000);
    k = 0;
    for (int i = 0; i < n && k < 6; i++) if (h[i].on && h[i].note == lowest) ons[k++] = h[i].t;
    CHECK(k >= 5 && ons[1] - ons[0] == 7500 && ons[2] - ons[1] == 4500 && ons[3] - ons[2] == 7500, "swing alternates 7500/4500 (%lld %lld %lld)",
          (long long)(ons[1] - ons[0]), (long long)(ons[2] - ons[1]), (long long)(ons[3] - ons[2]));

    /* bass-only and upper-only steps */
    e = pat_engine("b...u...........", 120.0, PRATE_16);
    en_push_midi(e, 0, 0x90, 36 + 3, 100);
    n = collect(e, 70, h, 4000);
    int first_group = 0, second_group = 0, bass_in_second = 0;
    for (int i = 0; i < n; i++) if (h[i].on) {
        if (h[i].t < 12000) { first_group++; CHECK(h[i].note == lowest, "b step plays only the bass"); }
        else { second_group++; if (h[i].note == lowest) bass_in_second = 1; }
    }
    CHECK(first_group == 1 && second_group >= 2 && !bass_in_second, "u step plays the upper notes only (%d/%d)", first_group, second_group);

    /* host sync: song position 0.1 beats = 0.4 of a 16th; pressing late waits for the next step (3600 samples) */
    e = pat_engine("xxxxxxxxxxxxxxxx", 120.0, PRATE_16);
    e->playing = 1; e->ppq = 0.1;
    en_push_midi(e, 0, 0x90, 36 + 3, 100);
    {
        static float L[512], R[512];
        int64_t first = -1;
        for (int b = 0; b < 20 && first < 0; b++) {
            int64_t t0 = e->now;
            en_process(e, L, R, 512);
            for (int i = 0; i < e->nout; i++) if ((e->out[i].d[0] & 0xF0) == 0x90 && first < 0) first = t0 + e->out[i].frame;
            e->nout = 0;
            e->ppq += 512.0 / 48000.0 * 2.0; /* host advances 120 bpm */
        }
        CHECK(first >= 3599 && first <= 3601, "synced start on the next 16th (%lld)", (long long)first);
    }

    /* releasing the pad stops the pattern; nothing left hanging */
    e = pat_engine("X.xX.xX.x.X.x.X.", 100.0, PRATE_16);
    e->swing = 0.3f;
    en_push_midi(e, 0, 0x90, 36 + 5, 100);
    collect(e, 50, h, 4000);
    en_push_midi(e, 0, 0x80, 36 + 5, 0);
    n = collect(e, 400, h, 4000);
    int stray = 0;
    for (int i = 0; i < n; i++) if (h[i].on) stray++;
    int refs = 0;
    for (int i = 0; i < 128; i++) refs += e->out_ref[i];
    CHECK(stray == 0 && refs == 0 && en_owner_count(e) == 0 && en_sounding(e) == 0, "pattern stops cleanly (%d %d)", stray, refs);

    /* random abuse with patterns and sync toggling */
    unsigned rng = 99;
    long on_count[128] = {0}, off_count[128] = {0};
    e = pat_engine("X.xb.uU-x.X-b.u.", 128.0, PRATE_16T);
    static float L[512], R[512];
    for (int it = 0; it < 3000; it++) {
        rng = rng * 1103515245u + 12345u;
        int r = (int)(rng >> 8);
        if (r % 3 == 0) en_push_midi(e, r % 512, 0x90, (unsigned char)(36 + (r >> 4) % 20), 80);
        if (r % 4 == 1) en_push_midi(e, (r >> 3) % 512, 0x80, (unsigned char)(36 + (r >> 6) % 20), 0);
        if (it % 300 == 0) { e->pat_rate = (it / 300) % PRATE_COUNT; e->swing = (float)((it / 300) % 4) / 4.f; e->playing = (it / 300) & 1; }
        if (it % 777 == 0) e->pattern_on = !e->pattern_on;
        if (it % 500 == 250) { e->smart = (it / 500) % SMART_COUNT; e->smart_mode = (it / 500) % SMODE_COUNT; e->dirty = 1; } /* smart pads mid-play */
        e->ppq += 512.0 / 48000.0 * 128.0 / 60.0;
        en_process(e, L, R, 512);
        for (int i = 0; i < e->nout; i++) { if ((e->out[i].d[0] & 0xF0) == 0x90) on_count[e->out[i].d[1]]++; else off_count[e->out[i].d[1]]++; }
        e->nout = 0;
    }
    for (int nn = 0; nn < 128; nn++) en_push_midi(e, 0, 0x80, (unsigned char)nn, 0);
    for (int b = 0; b < 1200; b++) {
        en_process(e, L, R, 512);
        for (int i = 0; i < e->nout; i++) { if ((e->out[i].d[0] & 0xF0) == 0x90) on_count[e->out[i].d[1]]++; else off_count[e->out[i].d[1]]++; }
        e->nout = 0;
    }
    int bal = 1;
    for (int nn = 0; nn < 128; nn++) if (on_count[nn] != off_count[nn]) bal = 0;
    CHECK(bal && en_owner_count(e) == 0 && en_sounding(e) == 0, "random pattern abuse: balanced MIDI, nothing stuck");

    /* output channel */
    e = pat_engine("X---------------", 120.0, PRATE_16);
    e->out_channel = 9;
    en_push_midi(e, 0, 0x90, 36, 100);
    {
        en_process(e, L, R, 512);
        CHECK(e->nout > 0 && e->out[0].d[0] == 0x99, "MIDI out on channel 10 (0x%02x)", e->nout ? e->out[0].d[0] : 0);
        e->nout = 0;
    }
    for (int i = 0; i < EN_NUM_PATTERNS; i++) {
        CHECK(strlen(EN_PATTERNS[i].steps) == EN_STEPS, "preset %s has 16 steps", EN_PATTERNS[i].name);
        for (int s2 = 0; s2 < EN_STEPS; s2++) CHECK(strchr(EN_STEP_CHARS, EN_PATTERNS[i].steps[s2]) != 0, "preset %s valid chars", EN_PATTERNS[i].name);
    }
}

/* ---- hold, repeat, melody, MIDI import ---- */
static void test_tools(void) {
    static Engine e;
    static float L[512], R[512];
    /* Hold: chord keeps sounding after release; another pad replaces it; same pad again turns it off */
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_RNB; e.dirty = 1; e.hold = 1;
    en_push_midi(&e, 0, 0x90, 36, 100); en_push_midi(&e, 100, 0x80, 36, 0);
    run(&e, 20, 512, L, R);
    CHECK(en_owner_count(&e) == 1 && en_sounding(&e) > 0, "hold keeps the chord after pad release");
    en_push_midi(&e, 0, 0x90, 37, 100); en_push_midi(&e, 100, 0x80, 37, 0);
    run(&e, 2, 512, L, R);
    CHECK(en_owner_count(&e) == 1 && e.latched_note == 37, "another pad replaces the held chord (owners %d)", en_owner_count(&e));
    en_push_midi(&e, 0, 0x90, 37, 100); en_push_midi(&e, 100, 0x80, 37, 0);
    run(&e, 400, 512, L, R);
    CHECK(en_owner_count(&e) == 0 && en_sounding(&e) == 0, "same pad again turns hold off");
    en_push_midi(&e, 0, 0x90, 38, 100); en_push_midi(&e, 100, 0x80, 38, 0);
    run(&e, 4, 512, L, R);
    e.hold = 0;
    run(&e, 400, 512, L, R);
    CHECK(en_owner_count(&e) == 0 && en_sounding(&e) == 0, "switching hold off releases the latched chord");

    /* Learn all 16 pads: an MPC whose pads send rows top-down (pad 1 = note 48 ... pad 13 = note 36) */
    {
        static const int SENDS[16] = {48, 49, 50, 51, 44, 45, 46, 47, 40, 41, 42, 43, 36, 37, 38, 39};
        en_init(&e, 48000.f);
        e.lp.mode = VC_MODE_RNB; e.dirty = 1;
        e.learn_all = 1;
        for (int k = 0; k < 16; k++) { en_push_midi(&e, 0, 0x90, (unsigned char)SENDS[k], 100); en_push_midi(&e, 10, 0x80, (unsigned char)SENDS[k], 0); run(&e, 1, 512, L, R); }
        CHECK(e.map_set && e.learn_all == 0, "learning finishes after 16 pads");
        CHECK(en_sounding(&e) == 0, "learning taps don't play");
        int ok = 1;
        for (int k = 0; k < 16; k++) if (en_pad_index(&e, SENDS[k]) != k) ok = 0;
        CHECK(ok, "every learned pad maps to its own position");
        CHECK(en_pad_index(&e, 48 + 16) == 16 && en_pad_index(&e, 39 + 48) == 63, "banks B-D follow the learned layout");
        CHECK(en_pad_index(&e, 100) == -1, "unlearned notes are ignored");
        en_push_midi(&e, 0, 0x90, 48, 100); run(&e, 1, 512, L, R);
        CHECK(e.last_pad == 0 && en_sounding(&e) > 0, "MPC pad 1 plays pad 1's chord (last pad %d)", e.last_pad);
        en_push_midi(&e, 0, 0x80, 48, 0); run(&e, 400, 512, L, R);
        e.learn = 1;   /* the simple Learn pad 1 replaces a learned layout */
        en_push_midi(&e, 0, 0x90, 60, 100); en_push_midi(&e, 10, 0x80, 60, 0); run(&e, 1, 512, L, R);
        CHECK(!e.map_set && e.pad_base == 60 && en_pad_index(&e, 61) == 1, "Learn pad 1 switches back to a simple layout");
        run(&e, 400, 512, L, R);
    }

    /* MPC Note Repeat (1/32 at 120 bpm): every retrigger sends its note-offs before the next note-ons */
    {
        en_init(&e, 48000.f);
        e.lp.mode = VC_MODE_RNB; e.dirty = 1;
        int maxv = 0;
        for (long b = 0; b < 48000 * 6 / 256; b++) {
            for (int f = 0; f < 256; f++) {
                long s = b * 256 + f;
                if (s % 3000 == 0) en_push_midi(&e, f, 0x90, 36, 100);
                if (s % 3000 == 2800) en_push_midi(&e, f, 0x80, 36, 0);
            }
            en_process(&e, L, R, 256);
            e.nout = 0;
            if (en_sounding(&e) > maxv) maxv = en_sounding(&e);
        }
        CHECK(maxv > 0 && maxv <= VC_MAX_NOTES, "note repeat never stacks notes (%d)", maxv);
        run(&e, 4, 256, L, R);
        CHECK(en_sounding(&e) == 0 && en_owner_count(&e) == 0, "note repeat leaves nothing on");
    }

    /* Repeat at 1/8, 120 bpm = 12000 samples at 48 kHz */
    static Hit h[4000];
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_TYPES; e.dirty = 1; e.midi_out = 1; e.tempo = 120.0; e.repeat = REP_8;
    en_push_midi(&e, 0, 0x90, 36 + 3, 100);
    int n = collect(&e, 120, h, 4000), low = 999;
    for (int i = 0; i < n; i++) if (h[i].on && h[i].note < low) low = h[i].note;
    int64_t ons[8]; int k = 0;
    for (int i = 0; i < n && k < 8; i++) if (h[i].on && h[i].note == low) ons[k++] = h[i].t;
    CHECK(k >= 4, "repeat retriggers (%d)", k);
    for (int i = 1; i < k; i++) CHECK(ons[i] - ons[i - 1] == 12000, "repeat spacing %lld", (long long)(ons[i] - ons[i - 1]));
    en_push_midi(&e, 0, 0x80, 36 + 3, 0);
    run(&e, 300, 512, L, R);
    CHECK(en_owner_count(&e) == 0 && en_sounding(&e) == 0, "repeat stops on release");

    /* Melody: notes above the chord, from the chord and the scale; stops with the chord */
    en_init(&e, 48000.f);
    e.lp.mode = VC_MODE_KEY; e.lp.key = 0; e.lp.scale = 0; e.dirty = 1; /* C major */
    e.midi_out = 1; e.tempo = 120.0; e.mel_mode = MEL_BUSY; e.mel_rate = MRATE_16;
    en_push_midi(&e, 0, 0x90, 36, 100);   /* Cmaj7 */
    n = collect(&e, 400, h, 4000);
    int mel = 0, bad = 0;
    for (int i = 0; i < n; i++) if (h[i].on && h[i].note >= 67) {
        mel++;
        if (!(0xAB5 & (1 << (h[i].note % 12)))) bad++;
    }
    CHECK(mel >= 10, "melody plays over the chord (%d notes)", mel);
    CHECK(bad == 0, "melody notes fit C major (%d outside)", bad);
    long ons2[128] = {0}, offs2[128] = {0};
    for (int i = 0; i < n; i++) { if (h[i].on) ons2[h[i].note]++; else offs2[h[i].note]++; }
    en_push_midi(&e, 0, 0x80, 36, 0);
    int n2 = collect(&e, 400, h, 4000);
    int after = 0;
    for (int i = 0; i < n2; i++) { if (h[i].on) { after++; ons2[h[i].note]++; } else offs2[h[i].note]++; }
    int bal = 1; for (int i = 0; i < 128; i++) if (ons2[i] != offs2[i]) bal = 0;
    CHECK(after == 0 && bal && en_owner_count(&e) == 0, "melody stops with the chord, MIDI balanced (%d late notes)", after);

    /* MIDI import: write a progression with the exporter, read it back, chords named correctly */
    const char *syms[] = {"Dbmaj7", "C7", "Fm7", "Ebm7", "Ab7", "C/E", "Fmaj7/G"};
    int ns = 7;
    MfChord mc[8];
    for (int i = 0; i < ns; i++) {
        ChordSpec c; vc_chord_parse(syms[i], &c);
        Voicing v; vc_voice(&c, VC_VOICE_BASS_UPPER, 0, 0, 0, &v);
        memset(&mc[i], 0, sizeof(mc[i]));
        mc[i].start_beats = 4.f * i; mc[i].dur_beats = 4.f; mc[i].n = v.n; memcpy(mc[i].notes, v.notes, (size_t)v.n); mc[i].vel = 90;
        strcpy(mc[i].name, syms[i]);
        if (i == 5) { /* first inversion C/E written explicitly */
            unsigned char ce[4] = {40, 48, 55, 60}; mc[i].n = 4; memcpy(mc[i].notes, ce, 4);
        }
    }
    vc_midi_write("/tmp/vc_import_test.mid", "t", "", mc, ns, 100, 4, 4);
    ImportChord ic[16]; char err[96];
    int got = vc_midi_import("/tmp/vc_import_test.mid", ic, 16, err, sizeof(err));
    CHECK(got == ns, "imported %d chords (%s)", got, got < 0 ? err : "ok");
    for (int i = 0; i < got && i < ns; i++) {
        char nm[32]; vc_chord_name(&ic[i].spec, 1, nm, sizeof(nm));
        ChordSpec want; vc_chord_parse(syms[i], &want);
        CHECK(vc_chord_pcmask(&ic[i].spec) == vc_chord_pcmask(&want) && ic[i].spec.root == want.root && ic[i].spec.bass == want.bass,
              "import chord %d: %s (want %s)", i + 1, nm, syms[i]);
        CHECK(ic[i].n == mc[i].n && !memcmp(ic[i].notes, mc[i].notes, (size_t)mc[i].n), "import keeps exact notes for %s", syms[i]);
    }
    unsigned char odd[3] = {60, 61, 66}; ChordSpec os; vc_identify_chord(odd, 3, &os);
    CHECK(os.quality == -1 && os.ncustom == 3, "unnamed clusters fall back to their intervals");
    got = vc_midi_import("/nonexistent.mid", ic, 16, err, sizeof(err));
    CHECK(got < 0, "missing file reported");
}

/* split keyboard: chords under the split, smart notes from the split up, black keys silent, no audio ever */
static void test_keyboard(void) {
    static Engine e;
    static float L[512], R[512];
    static Hit h[4000];
    int idx = -1;
    en_init(&e, 48000.f);
    CHECK(e.midi_out == 1, "MIDI out is on from the start");
    e.lp.mode = VC_MODE_KEY; e.lp.key = 0; e.lp.scale = 0; e.dirty = 1; /* C major */
    en_process(&e, L, R, 64);
    e.kb_mode = 1; e.kb_split = 60;
    CHECK(en_kb_lookup(&e, 36, &idx) == KB_CHORD && idx == 0, "C two octaves under the split is pad 1 (%d)", idx);
    CHECK(en_kb_lookup(&e, 38, &idx) == KB_CHORD && idx == 1, "next white key is pad 2 (%d)", idx);
    CHECK(en_kb_lookup(&e, 59, &idx) == KB_CHORD && idx == 13, "the key under the split is pad 14 (%d)", idx);
    CHECK(en_kb_lookup(&e, 35, &idx) == KB_CHORD && idx == 15 && en_kb_lookup(&e, 33, &idx) == KB_CHORD && idx == 14, "the two white keys below are pads 16 and 15");
    CHECK(en_kb_lookup(&e, 37, &idx) == KB_SHIFT && idx == KBC_KEY_DOWN && en_kb_lookup(&e, 39, &idx) == KB_SHIFT && idx == KBC_KEY_UP, "left C# and D# shift the key down and up");
    CHECK(en_kb_lookup(&e, 42, &idx) == KB_SHIFT && idx == KBC_SCALE_PREV && en_kb_lookup(&e, 56, &idx) == KB_SHIFT && idx == KBC_SCALE_NEXT, "left F# and G# shift the scale");
    CHECK(en_kb_lookup(&e, 58, &idx) == KB_SHIFT && idx == KBC_BANK_NEXT, "left A# is the bank shifter");
    CHECK(en_kb_lookup(&e, 61, &idx) == KB_GEN && idx == 0 && en_kb_lookup(&e, 63, &idx) == KB_GEN && idx == 1 &&
          en_kb_lookup(&e, 66, &idx) == KB_GEN && idx == 2 && en_kb_lookup(&e, 68, &idx) == KB_GEN && idx == 3 &&
          en_kb_lookup(&e, 82, &idx) == KB_GEN && idx == 4, "right black keys are the five generators, in every octave");
    CHECK(e.gen[0].pattern == KG_ARP_UP && e.gen[1].pattern == KG_ARP_DOWN && e.gen[2].pattern == KG_ARP_UPDOWN &&
          e.gen[3].pattern == KG_MEL_SIMPLE && e.gen[4].pattern == KG_MEL_BUSY, "the five keys start as three arpeggios and two melodies");
    CHECK(en_kb_lookup(&e, 60, &idx) == KB_SMART && idx == 0 && en_kb_lookup(&e, 62, &idx) == KB_SMART && idx == 1, "white keys from the split count up the smart notes");
    e.kb_bank = 2;
    CHECK(en_kb_lookup(&e, 36, &idx) == KB_CHORD && idx == 32, "chord keys play the bank on screen (%d)", idx);
    e.kb_bank = 0;
    e.kb_split = 61; /* a split on a black key starts at the next white key */
    CHECK(en_kb_lookup(&e, 60, &idx) == KB_CHORD && en_kb_lookup(&e, 62, &idx) == KB_SMART && idx == 0, "split on a black key");
    e.kb_split = 60;
    int every = 1;
    for (int n = 0; n < 128; n++) { int k = en_kb_lookup(&e, n, &idx); if (k == KB_CHORD && (idx < 0 || idx > 15)) every = 0; if (k == KB_SMART && idx < 0) every = 0; }
    CHECK(every, "every key maps inside the bank");

    /* a chord key plays exactly what its pad plays */
    Voicing want = e.voicings[1];
    en_push_midi(&e, 0, 0x90, 38, 100);
    int n = collect(&e, 2, h, 4000), ons = 0, match = 1;
    for (int i = 0; i < n; i++) if (h[i].on) { int f = 0; for (int j = 0; j < want.n; j++) if (want.notes[j] == h[i].note) f = 1; if (!f) match = 0; ons++; }
    CHECK(ons == want.n && match && e.last_pad == 1, "chord key D plays pad 2's chord (%d notes, pad %d)", ons, e.last_pad);
    /* smart keys follow that chord: with "Chord tones" every key is a tone of it */
    e.smart_mode = SMODE_CHORD; en_smart_update(&e);
    int cmask = 0; for (int i = 0; i < e.own_chord.npcs; i++) cmask |= 1 << e.own_chord.pcs[i];
    int fit = 1, rising = 1, prev = -1;
    for (int key = 60; key <= 96; key++) {
        if (en_kb_lookup(&e, key, &idx) != KB_SMART) continue;
        int out = en_smart_note(&e, idx);
        if (!(cmask & (1 << (out % 12)))) fit = 0;
        if (out <= prev) rising = 0;
        prev = out;
    }
    CHECK(fit && rising && cmask, "smart keys are chord tones, rising up the keyboard");
    CHECK(en_smart_note(&e, 0) % 12 == e.own_chord.root, "the split key plays the chord's root");
    en_push_midi(&e, 0, 0x80, 38, 0);   /* let the chord go: the smart keys keep following it */
    collect(&e, 2, h, 4000);
    en_push_midi(&e, 0, 0x90, 64, 90);
    n = collect(&e, 2, h, 4000); ons = 0; int got = -1;
    for (int i = 0; i < n; i++) if (h[i].on) { ons++; got = h[i].note; }
    CHECK(ons == 1 && got == en_smart_note(&e, 2), "a smart key sends one note (%d)", got);
    en_push_midi(&e, 0, 0x80, 64, 0);
    collect(&e, 2, h, 4000);
    /* a left black key sends no notes: it leaves a command for the plugin */
    e.kb_ncmd = 0;
    en_push_midi(&e, 0, 0x90, 39, 90); en_push_midi(&e, 10, 0x80, 39, 0);
    n = collect(&e, 2, h, 4000); ons = 0;
    for (int i = 0; i < n; i++) ons += h[i].on;
    CHECK(ons == 0 && e.kb_ncmd == 1 && e.kb_cmds[0] == KBC_KEY_UP && en_owner_count(&e) == 0, "a left black key sends no notes and asks for key up (%d cmds)", e.kb_ncmd);
    e.kb_ncmd = 0;
    /* right black keys: one-finger generators over the chord, while held */
    e.tempo = 120.0; e.mel_rate = MRATE_16; e.playing = 0;
    for (int gk = 0; gk < EN_GEN_KEYS; gk++) {
        static const int KEYS[EN_GEN_KEYS] = {61, 63, 66, 68, 70};
        int key = KEYS[gk], kind = e.gen[gk].pattern;
        en_push_midi(&e, 0, 0x90, (unsigned char)key, 100);
        n = collect(&e, 100, h, 4000);                    /* ~1 s */
        int non = 0, inchord = 1, inpool = 1, maxsim = 0, simul = 0, seq[64];
        for (int i = 0; i < n; i++) {
            if (h[i].on) { if (non < 64) seq[non] = h[i].note; non++; simul++; if (simul > maxsim) maxsim = simul;
                           if (!(cmask & (1 << (h[i].note % 12)))) inchord = 0;
                           if (!((cmask | e.scale_pcs_mask) & (1 << (h[i].note % 12)))) inpool = 0; }
            else simul--;
        }
        CHECK(non >= 3 && maxsim == 1 && inpool, "generator %d plays a line of single notes that fit (%d notes)", kind, non);
        if (kind <= KG_STABS) CHECK(inchord, "arpeggio %d uses chord tones only", kind);
        if (kind == KG_ARP_UP) CHECK(non >= 3 && seq[1] > seq[0] && seq[2] > seq[1] && seq[0] % 12 == e.own_chord.root, "arp up climbs from the root (%d %d %d)", seq[0], seq[1], seq[2]);
        if (kind == KG_ARP_DOWN) CHECK(non >= 3 && seq[1] < seq[0] && seq[2] < seq[1], "arp down falls (%d %d %d)", seq[0], seq[1], seq[2]);
        if (kind == KG_ARP_UP) { /* 1/16 at 120 bpm = 6000 samples */
            int64_t first = -1, second = -1;
            for (int i = 0; i < n; i++) if (h[i].on) { if (first < 0) first = h[i].t; else if (second < 0) second = h[i].t; }
            CHECK(second - first == 6000, "generator steps at its key's rate (%lld)", (long long)(second - first));
        }
        en_push_midi(&e, 0, 0x80, (unsigned char)key, 0);
        n = collect(&e, 20, h, 4000);
        CHECK(en_sounding(&e) == 0 && en_owner_count(&e) == 0 && e.mel_key_kind == 0, "generator %d stops when its key is released", kind);
    }
    {   /* each key's own settings: pattern, rate, range, tones, note length */
        GenKey keep = e.gen[0];
        int np = e.own_chord.npcs;
        /* stabs: the whole chord at once, every step */
        e.gen[0].pattern = KG_STABS;
        en_push_midi(&e, 0, 0x90, 61, 100);
        n = collect(&e, 40, h, 4000);
        int simul = 0, maxsim = 0, okc = 1;
        for (int i = 0; i < n; i++) { if (h[i].on) { if (++simul > maxsim) maxsim = simul; if (!(cmask & (1 << (h[i].note % 12)))) okc = 0; } else simul--; }
        CHECK(maxsim == np && okc, "stabs play the whole chord (%d of %d notes)", maxsim, np);
        en_push_midi(&e, 0, 0x80, 61, 0); collect(&e, 20, h, 4000);
        CHECK(en_sounding(&e) == 0 && en_owner_count(&e) == 0, "stabs stop on release");
        /* random arpeggio, one octave, root and fifth only, 1/8 with half-length notes */
        e.gen[0].pattern = KG_ARP_RANDOM; e.gen[0].range = 1; e.gen[0].tones = GT_ROOT5; e.gen[0].rate = RATE_8; e.gen[0].gate = 0.5f;
        en_push_midi(&e, 0, 0x90, 61, 100);
        n = collect(&e, 200, h, 4000);
        int lo2 = 999, hi2 = 0, pcs2 = 0, cnt2 = 0; int64_t on0 = -1, on1 = -1, off0 = -1;
        for (int i = 0; i < n; i++) {
            if (h[i].on) { cnt2++; if (h[i].note < lo2) lo2 = h[i].note; if (h[i].note > hi2) hi2 = h[i].note; pcs2 |= 1 << (h[i].note % 12);
                           if (on0 < 0) on0 = h[i].t; else if (on1 < 0) on1 = h[i].t; }
            else if (off0 < 0 && on0 >= 0) off0 = h[i].t;
        }
        int npc = 0; for (int k = 0; k < 12; k++) npc += (pcs2 >> k) & 1;
        CHECK(cnt2 >= 6 && hi2 - lo2 < 12, "range 1 keeps the arpeggio inside an octave (%d..%d)", lo2, hi2);
        CHECK(npc <= 2 && (pcs2 & (1 << e.own_chord.root)) && !(pcs2 & ~cmask), "root+5th uses two chord tones (%d)", npc);
        CHECK(on1 - on0 == 12000, "the key's own rate: 1/8 = 12000 samples (%lld)", (long long)(on1 - on0));
        CHECK(off0 - on0 == 6000, "the key's own note length: 50%% of the step (%lld)", (long long)(off0 - on0));
        en_push_midi(&e, 0, 0x80, 61, 0); collect(&e, 20, h, 4000);
        /* three octaves reach higher than one */
        e.gen[0].pattern = KG_ARP_UP; e.gen[0].range = 3; e.gen[0].tones = GT_ALL; e.gen[0].rate = RATE_32;
        en_push_midi(&e, 0, 0x90, 61, 100);
        n = collect(&e, 200, h, 4000);
        lo2 = 999; hi2 = 0;
        for (int i = 0; i < n; i++) if (h[i].on) { if (h[i].note < lo2) lo2 = h[i].note; if (h[i].note > hi2) hi2 = h[i].note; }
        CHECK(hi2 - lo2 > 24 && hi2 - lo2 < 36, "range 3 covers three octaves (%d..%d)", lo2, hi2);
        en_push_midi(&e, 0, 0x80, 61, 0); collect(&e, 20, h, 4000);
        e.gen[0] = keep;
        CHECK(en_sounding(&e) == 0 && en_owner_count(&e) == 0, "nothing left on after the settings tests");
    }
    {   /* the arp follows a chord change made while its key is held, and a higher octave's key plays higher */
        en_push_midi(&e, 0, 0x90, 61, 100);
        collect(&e, 20, h, 4000);
        en_push_midi(&e, 0, 0x90, 40, 100); en_push_midi(&e, 50, 0x80, 40, 0);   /* left hand: pad 3 */
        collect(&e, 4, h, 4000);
        int m2 = 0; for (int i = 0; i < e.own_chord.npcs; i++) m2 |= 1 << e.own_chord.pcs[i];
        n = collect(&e, 60, h, 4000);
        int ok2 = 1, cnt = 0;
        for (int i = 0; i < n; i++) if (h[i].on) { cnt++; if (!(m2 & (1 << (h[i].note % 12)))) ok2 = 0; }
        CHECK(cnt >= 3 && ok2 && m2 != cmask, "a held arpeggio moves to the new chord");
        en_push_midi(&e, 0, 0x80, 61, 0); collect(&e, 4, h, 4000);
        int top[2] = {0, 0};
        for (int o = 0; o < 2; o++) {
            en_push_midi(&e, 0, 0x90, (unsigned char)(61 + 12 * o), 100);
            n = collect(&e, 60, h, 4000);
            for (int i = 0; i < n; i++) if (h[i].on && h[i].note > top[o]) top[o] = h[i].note;
            en_push_midi(&e, 0, 0x80, (unsigned char)(61 + 12 * o), 0); collect(&e, 4, h, 4000);
        }
        CHECK(top[1] == top[0] + 12, "the same black key an octave up plays an octave higher (%d vs %d)", top[1], top[0]);
        cmask = m2;
    }
    e.kb_ncmd = 0;
    /* "Scale" notes: every smart key is in the scale or the chord */
    e.smart_mode = SMODE_SCALE; en_smart_update(&e);
    fit = 1;
    for (int j = 0; j < 30; j++) if (!((cmask | e.scale_pcs_mask) & (1 << (en_smart_note(&e, j) % 12)))) fit = 0;
    CHECK(fit, "scale notes stay in the scale");
    n = collect(&e, 4, h, 4000);
    CHECK(en_sounding(&e) == 0 && en_owner_count(&e) == 0, "releasing the keys leaves nothing on");

    /* screen taps are always pads, even in keyboard mode */
    en_push_pad(&e, 0, 1, 37, 100);       /* note 37 = pad 2 in the default layout, a black key on the keyboard */
    n = collect(&e, 2, h, 4000); ons = 0;
    for (int i = 0; i < n; i++) ons += h[i].on;
    CHECK(ons == e.voicings[1].n && e.last_pad == 1, "a screen tap still plays its pad (%d)", ons);
    en_push_pad(&e, 0, 0, 37, 0);
    collect(&e, 4, h, 4000);

    /* random keyboard abuse with pattern, hold-less: balanced MIDI, nothing stuck, and never any audio */
    unsigned rng = 77; int bal[128] = {0}, okbal = 1; double energy = 0;
    e.pattern_on = 1; e.tempo = 120.0;
    for (int b = 0; b < 3000; b++) {
        rng = rng * 1664525u + 1013904223u;
        int key = 24 + (int)((rng >> 16) % 80);
        if ((rng >> 8) % 3 == 0) en_push_midi(&e, (int)((rng >> 4) % 256), (rng >> 12) & 1 ? 0x90 : 0x80, (unsigned char)key, 100);
        if (b % 500 == 250) e.kb_mode ^= 1;
        if (b % 700 == 350) e.kb_split = 48 + (int)((rng >> 20) % 24);
        en_process(&e, L, R, 256);
        for (int i = 0; i < 256; i++) energy += L[i] * L[i] + R[i] * R[i];
        for (int i = 0; i < e.nout; i++) { int st = e.out[i].d[0] & 0xF0; if (st == 0x90) bal[e.out[i].d[1]]++; else if (st == 0x80) bal[e.out[i].d[1]]--; }
        e.nout = 0;
    }
    e.pattern_on = 0;
    for (int k = 0; k < 128; k++) en_push_midi(&e, 0, 0x80, (unsigned char)k, 0);
    for (int b = 0; b < 8; b++) {
        en_process(&e, L, R, 256);
        for (int i = 0; i < e.nout; i++) { int st = e.out[i].d[0] & 0xF0; if (st == 0x90) bal[e.out[i].d[1]]++; else if (st == 0x80) bal[e.out[i].d[1]]--; }
        e.nout = 0;
    }
    for (int k = 0; k < 128; k++) if (bal[k]) okbal = 0;
    CHECK(okbal && en_sounding(&e) == 0 && en_owner_count(&e) == 0, "random keyboard abuse: balanced MIDI, nothing stuck");
    CHECK(energy == 0.0, "the plugin never makes audio");
}

int main(void) {
    printf("chord qualities...\n"); test_qualities_against_spelled();
    printf("parser...\n"); test_parse();
    printf("voicings...\n"); test_voicings();
    printf("song data...\n"); test_songs();
    printf("layouts...\n"); test_layouts();
    printf("note handling...\n"); test_note_handling();
    printf("pattern generator...\n"); test_patterns();
    printf("hold, repeat, melody, import...\n"); test_tools();
    printf("split keyboard...\n"); test_keyboard();
    printf("%d checks, %d failures\n", checks, fails);
    return fails ? 1 : 0;
}
