#!/bin/sh
# Package the plugin (run by the GitHub build after the ARM build): dist/VelvetKeys-SDK-<version>.zip, the official
# Akai MPC Plugin SDK layout that goes into a "VST2 Plugins" folder. No root installer is made any more: it would
# overwrite /sdcard/vst/velvetchords.so, which may be a different, newer Velvet Chords.
set -e
VER="${1:-1.0.0}"
mkdir -p dist
sh scripts/sdk_package.sh "$VER"
