#ifndef VC_ENGINE_H
#define VC_ENGINE_H
#include "layouts.h"
#include <stdint.h>

#define EN_QUEUE 1024
#define EN_OWNERS 128
#define EN_MIDI_IN 1024
#define EN_MIDI_OUT 1024

enum { STRUM_UP, STRUM_DOWN, STRUM_ALT, STRUM_COUNT };
enum { ARP_OFF, ARP_UP, ARP_DOWN, ARP_UPDOWN, ARP_PLAYED /* random order */, ARP_COUNT };
enum { RATE_4, RATE_8, RATE_8T, RATE_16, RATE_16T, RATE_32, RATE_COUNT };
enum { VEL_LINEAR, VEL_SOFT, VEL_HARD, VEL_FIXED, VEL_COUNT };

/* Pattern generator. Step characters:
 *   .  rest (silence)      x  chord          X  accented chord
 *   b  bass note only      u  upper notes    U  accented upper notes
 *   -  tie (keep the previous step sounding) */
#define EN_STEPS 16
enum { PRATE_8, PRATE_8T, PRATE_16, PRATE_16T, PRATE_32, PRATE_COUNT };
typedef struct { const char *name; const char *steps; } PatternPreset;
extern const PatternPreset EN_PATTERNS[];
extern const int EN_NUM_PATTERNS;
extern const char EN_STEP_CHARS[]; /* index -> step character, for editing */
int en_step_index(char c);

/* Smart Scale pads: single notes that follow the current chord */
enum { SMART_OFF, SMART_SPLIT /* pads 9-16 */, SMART_FOLLOW /* all pads, chord from another instance */, SMART_COUNT };
enum { SMODE_CHORD, SMODE_SCALE, SMODE_BASS, SMODE_COUNT };
typedef struct {
    int valid, root, bass, npcs, flats;
    int pcs[12];     /* chord pitch classes, ordered upward from the root */
    char name[24];
} SmartChord;
/* the chord most recently played by any Velvet Chords instance in this process (MPC loads every instance into
 * the same program, so this is how a second instance follows the first) */
typedef struct { volatile unsigned version; int source; SmartChord chord; } SharedChord;
extern SharedChord g_vc_shared;
/* key + scale shared between copies (instance sync) */
typedef struct { volatile unsigned version; int source, key, scale; } SharedKey;
extern SharedKey g_vc_key;

enum { MEL_OFF, MEL_SIMPLE, MEL_BUSY, MEL_COUNT };
enum { MRATE_8, MRATE_8T, MRATE_16, MRATE_COUNT };
enum { REP_OFF, REP_4, REP_8, REP_8T, REP_16, REP_16T, REP_32, REP_COUNT };

typedef struct { int64_t when; int owner; unsigned char slot, vel; } QEvent;
typedef struct { int frame; unsigned char d[3]; unsigned char pad_only; } MidiMsg;

typedef struct {
    int owner, held, sustained;
    int n;
    unsigned char notes[VC_MAX_NOTES];
    unsigned char sounding[VC_MAX_NOTES];
    float vel, vel_base;
} OwnerRec;

/* what a right-hand black key plays; each of the five keys has its own pattern, rate, range, tones and note length */
enum { KG_NONE, KG_ARP_UP, KG_ARP_DOWN, KG_ARP_UPDOWN, KG_ARP_RANDOM, KG_STABS, KG_MEL_SIMPLE, KG_MEL_BUSY, KG_COUNT };
enum { GT_ALL, GT_TRIAD, GT_ROOT5, GT_COUNT };  /* which chord tones a generator uses */
#define EN_GEN_KEYS 5
typedef struct { int pattern /* KG_* */, rate /* RATE_* */, range /* octaves 1..3 */, tones /* GT_* */; float gate; } GenKey;

typedef struct Engine {
    float sr;
    int64_t now; /* absolute sample clock at the start of the current block */

    /* layout */
    LayoutParams lp;
    CustomPad custom[VC_PADS];
    PadChord pads[VC_PADS];
    Voicing voicings[VC_PADS];
    volatile int dirty;

    /* performance settings */
    int pad_base, learn, midi_out, midi_out_flush, edit_follow;
    signed char pad_map[128];      /* learned: incoming note -> pad 0..15 of bank A, -1 = not a learned pad */
    int map_set;                   /* a full 16-pad layout has been learned */
    int learn_all;                 /* 1..16 = waiting for that pad; 0 = not learning */
    float strum_ms;
    int strum_dir, strum_flip;
    int arp, arp_rate, vel_curve;
    int out_channel; /* 0-15 */
    double tempo;

    /* pattern generator */
    int pattern_on, pat_rate, pat_sync;
    float swing, gate; /* swing 0..1 (fraction of half a step), gate 0.1..1 */
    char pat[EN_STEPS];
    double ppq;        /* host song position at block start (quarter notes) */
    int playing;       /* host transport running */
    int pat_owner, pat_is_repeat;
    int hold, latched_note;        /* Hold: the latched pad's input note, -1 none */
    int repeat;                    /* REP_*: retrigger the chord at this rate */
    int mel_mode, mel_rate;        /* melody generator */
    int mel_owner, mel_parent, mel_prev;
    int64_t mel_k, mel_last_k, mel_off_at;
    double mel_grid;
    unsigned mel_rng;
    int64_t pat_k;     /* absolute index of the next step */
    double pat_grid;   /* sample time of the next step before swing */
    int64_t pat_off_at;
    int64_t pat_last_k;

    /* state */
    int pad_owner[128];
    OwnerRec owners[EN_OWNERS];
    int next_owner;
    int sustain;
    QEvent queue[EN_QUEUE];
    int nqueue;
    int arp_owner, arp_idx, arp_dirn, arp_slot;
    int64_t arp_next;
    unsigned rng;
    int out_ref[128];

    MidiMsg in[EN_MIDI_IN];
    int nin;
    MidiMsg out[EN_MIDI_OUT];
    int nout;
    int out_flush_n; /* the first this-many messages of the block are the note-offs for routes being switched off */

    /* smart scale */
    int smart, smart_mode, smart_oct, instance_id;
    int scale_pcs_mask;          /* key scale for "Scale" mode */
    SmartChord own_chord;        /* last chord this instance played */
    SmartChord smart_src;        /* chord the smart pads currently follow */
    unsigned shared_seen;
    unsigned char smart_notes[16];
    int smart_base, smart_m, smart_tones[12], smart_slash; /* the note series the smart pads and keys read from */

    /* split keyboard: white keys below the split play the bank's chords, white keys from the split up play
     * smart notes; black keys below the split shift key, scale and bank, black keys above it run one-finger
     * arpeggios and melodies over the current chord. Off = every note is a pad, as before */
    int kb_mode, kb_split, kb_bank;
    unsigned char kb_cmds[8];    /* left-hand black keys pressed this block (KBC_*), for the plugin to carry out */
    int kb_ncmd;
    int mel_key_kind;            /* KG_*: the generator a right-hand black key is running, 0 = none */
    int mel_gen;                 /* which key's settings it uses */
    GenKey gen[EN_GEN_KEYS];
    int mel_shift, mel_arp_i, mel_arp_dir;
    volatile int smart_changed;

    int last_pad; /* -1 none */
    int last_note_in;
    int events_changed; /* set when last_pad / pad_base / edit pad changed (for host display refresh) */
    int edit_pad_request; /* -1 none, else pad index to select for editing */
} Engine;

void en_init(Engine *e, float sr);
void en_set_sr(Engine *e, float sr);
void en_rebuild(Engine *e);
void en_reset(Engine *e); /* all notes off, clear queues */
void en_push_midi(Engine *e, int frame, unsigned char s, unsigned char d1, unsigned char d2);
void en_process(Engine *e, float *L, float *R, int n); /* replaces L/R */
int en_owner_count(const Engine *e);
float en_vel_curve(int curve, int vel);
int en_pad_index(const Engine *e, int note); /* pad 0..63 for an incoming note, -1 if it isn't a pad */
int en_smart_index(const Engine *e, int pad); /* -1 if the pad is a chord pad */
void en_smart_update(Engine *e);
int en_smart_note(const Engine *e, int i);   /* i-th note of the smart series (0 = lowest) */
int en_sounding(const Engine *e);            /* notes currently on at the MIDI output */
void en_push_pad(Engine *e, int frame, int on, int note, int vel); /* always a pad, even in keyboard mode (screen taps) */
/* split keyboard: what a key does: a chord (*idx = pad 0..63), a smart note (*idx = series index), a shifter or a generator */
enum { KB_NONE, KB_CHORD, KB_SMART, KB_SHIFT /* left black key: *idx = KBC_* */, KB_GEN /* right black key: *idx = which of the five, 0..4 */ };
/* black keys, in the order C# D# F# G# A#. Left of the split they are shifters, from the split up one-finger generators */
enum { KBC_KEY_DOWN, KBC_KEY_UP, KBC_SCALE_PREV, KBC_SCALE_NEXT, KBC_BANK_NEXT };
int en_kb_lookup(const Engine *e, int note, int *idx);

#endif
