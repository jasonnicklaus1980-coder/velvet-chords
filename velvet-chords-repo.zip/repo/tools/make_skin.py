#!/usr/bin/env python3
"""Generate the Velvet Chords MPC screen skin.

Output: <out>/Velvet Chords - VST - Velvet Chords/
  TUI.json                 pages, component definitions, parameter bindings
  Q-Links.json             Q-Link assignments per page
  Q-Links - 8by1.json      same, for 8-Q-Link hardware (identical, as in the JV-880 reference)
  *.png                    every image the pages use

The file format mirrors a working community skin (JV-880 by sd88me) supplied as reference; it is not documented by
Akai. Parameters are bound by NAME: indices come from the built plugin via tools/list_params, so the skin can't drift
from the code.

Visual language: flat studio hardware. Dark surfaces, 1px hairlines, small tracked uppercase labels, one amber
accent reserved for state (selected, playing). No gloss, no gradients on controls, no drop shadows.
Every image is drawn at 3x and downsampled for clean edges.

usage: make_skin.py <plugin.so> <list_params binary> <out dir>
"""
import json, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 628
SS = 3
FONT_DIR = "/usr/share/fonts/truetype/google-fonts"
LIVE_FONT = "Titillium Web"  # font the MPC uses for live text in the reference skin

# ---- palette
BG = "#0e0f11"
HEADER = "#131417"
SURFACE = "#16171a"       # panels
HAIRLINE = "#25272c"
CTRL = "#1b1d21"          # unselected control fill
CTRL_EDGE = "#2c2f35"
CTRL_SEL = "#23262b"      # selected control fill
FIELD = "#0b0c0e"
FIELD_EDGE = "#2a2d33"
ACCENT = "#f2a33a"
ACCENT_DIM = "#8a5f25"
INK_ON_ACCENT = "#17120a"
TEXT = "#e8e9eb"
TEXT_2 = "#a4a8b0"
LABEL = "#6c7079"
KEY_WHITE = "#dededa"; KEY_WHITE_EDGE = "#a9a9a4"; KEY_BLACK = "#1d1f23"
GOLD = ACCENT  # names used by older helpers
ROSE = ACCENT
BRIGHT = TEXT
MUTED = TEXT_2
INK = TEXT


def argb(hexrgb, a="ff"):
    return a + hexrgb.lstrip("#")


def font(weight, size):
    return ImageFont.truetype(os.path.join(FONT_DIR, "Poppins-%s.ttf" % weight), int(round(size)))


# ---------------------------------------------------------------- parameters
def load_params(so, lister):
    out = subprocess.run([lister, so], capture_output=True, text=True, check=True).stdout
    p = {}
    for line in out.splitlines():
        i, name = line.split("\t")[:2]
        p[name] = int(i)
    return p


# ---------------------------------------------------------------- drawing
class Art:
    """Draw at SS x in final-pixel coordinates; downsample on save."""

    def __init__(self, w, h, bg=None):
        self.w, self.h = w, h
        self.im = Image.new("RGBA", (w * SS, h * SS), bg or (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    def s(self, *v):
        return [x * SS for x in v]

    def rect(self, x0, y0, x1, y1, r=0, fill=None, edge=None, width=1, corners=(True, True, True, True)):
        self.d.rounded_rectangle(self.s(x0, y0, x1 - 1, y1 - 1), r * SS, fill=fill, outline=edge, width=int(width * SS), corners=corners)

    def line(self, x0, y0, x1, y1, fill, width=1):
        self.d.line(self.s(x0, y0, x1, y1), fill=fill, width=int(width * SS))

    def text(self, x, y, txt, size, fill, weight="Medium", anchor="la", tracking=0.0):
        f = font(weight, size * SS)
        if not tracking:
            self.d.text((x * SS, y * SS), txt, font=f, fill=fill, anchor=anchor)
            return
        widths = [self.d.textlength(c, font=f) for c in txt]
        total = sum(widths) + tracking * SS * (len(txt) - 1)
        cx = x * SS - (total / 2 if anchor[0] == "m" else total if anchor[0] == "r" else 0)
        for c, w in zip(txt, widths):
            self.d.text((cx, y * SS), c, font=f, fill=fill, anchor="l" + anchor[1])
            cx += w + tracking * SS

    def text_center(self, x0, y0, x1, y1, txt, size, fill, weight="Medium", tracking=0.0):
        f = font(weight, size * SS)
        _, t, _, b = self.d.textbbox((0, 0), "HX", font=f)
        y = (y0 + y1) / 2 * SS - (b - t) / 2 - t
        self.text((x0 + x1) / 2, y / SS, txt, size, fill, weight, anchor="ma", tracking=tracking)

    def label(self, x, y, txt):
        """section/control label: small, uppercase, tracked"""
        self.text(x, y, txt.upper(), 10.5, LABEL, "Medium", tracking=1.3)

    def done(self):
        return self.im.resize((self.w, self.h), Image.LANCZOS)


class Images:
    def __init__(self, outdir):
        self.dir = outdir
        self.made = set()

    def save(self, name, img):
        if name not in self.made:
            img.save(os.path.join(self.dir, name), optimize=True)
            self.made.add(name)
        return name

    def pad(self, n, on, w=148, h=120):
        """MPC-style pad tile: dark, active = amber outline + underline"""
        a = Art(w, h)
        if on:
            a.rect(1, 1, w - 1, h - 1, 6, fill=CTRL_SEL, edge=ACCENT, width=1.5)
            a.rect(10, h - 7, w - 10, h - 4, 1.5, fill=ACCENT)
        else:
            a.rect(1, 1, w - 1, h - 1, 6, fill=CTRL, edge=CTRL_EDGE, width=1)
        a.text(12, 10, "%02d" % n, 10.5, ACCENT if on else "#4d5159", "Medium", tracking=0.8)
        return self.save("vc_pad_%d_%dx%d_%s.png" % (n, w, h, "on" if on else "off"), a.done())

    def key(self, pc, on, w, h):
        """piano key of any size; white keys carry their note name above the scale dot"""
        black = pc in (1, 3, 6, 8, 10)
        names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        a = Art(w, h)
        if black:
            a.rect(0, 0, w, h, 3, fill=ACCENT if on else KEY_BLACK, edge="#08090a", corners=(False, False, True, True))
        else:
            a.rect(0, 0, w, h, 3, fill=ACCENT if on else KEY_WHITE, edge=KEY_WHITE_EDGE if not on else "#b97a22",
                   corners=(False, False, True, True))
            yy = h - 38
            a.text_center(0, yy, w, yy + 14, names[pc], 11 if w >= 52 else 10, INK_ON_ACCENT if on else "#55575c", "Medium")
        return self.save("vc_key_%d_%dx%d_%s.png" % (pc, w, h, "on" if on else "off"), a.done())

    def bigkey(self, n, on, w, h):
        """wide white key of the split keyboard; n > 0 = the pad number it plays (chord keys), 0 = plain"""
        a = Art(w, h)
        a.rect(1, 0, w - 1, h, 4, fill=ACCENT if on else KEY_WHITE, edge="#b97a22" if on else KEY_WHITE_EDGE,
               corners=(False, False, True, True))
        if n:
            a.text_center(0, h - 22, w, h - 8, "PAD %d" % n, 9.5, INK_ON_ACCENT if on else "#7a7c80", "Medium", tracking=0.8)
        return self.save("vc_bigkey_%d_%dx%d_%s.png" % (n, w, h, "on" if on else "off"), a.done())

    def bigblack(self, name, lines, w, h, on, draw_on=None):
        """black key of the split keyboard with its job written on it"""
        a = draw_on or Art(w, h)
        x0, y0 = (0, 0) if draw_on is None else on
        lit = draw_on is None and on
        a.rect(x0, y0, x0 + w, y0 + h, 4, fill=ACCENT if lit else KEY_BLACK, edge="#b97a22" if lit else "#08090a",
               corners=(False, False, True, True))
        for k, s in enumerate(lines):
            a.text_center(x0, y0 + h - 34 + k * 13, x0 + w, y0 + h - 21 + k * 13, s, 9, INK_ON_ACCENT if lit else "#c9cbd0", "Medium", tracking=0.6)
        if draw_on is not None:
            return None
        return self.save("vc_bigblack_%s_%s.png" % (name, "on" if on else "off"), a.done())

    def bigblack_sel(self, on, w, h):
        """right-hand black key: a selector; the picked one gets the amber outline and bar the pads use"""
        a = Art(w, h)
        a.rect(0, 0, w, h, 4, fill=KEY_BLACK, edge=ACCENT if on else "#08090a", width=1.5 if on else 1, corners=(False, False, True, True))
        if on:
            a.rect(8, h - 7, w - 8, h - 4, 1.5, fill=ACCENT)
        return self.save("vc_bigblack_sel_%s.png" % ("on" if on else "off"), a.done())

    def dot(self, on_black):
        a = Art(14, 14)
        a.d.ellipse(a.s(3, 3, 11, 11), fill="#c9ccd2" if on_black else "#26282c")
        return self.save("vc_dot_%s.png" % ("b" if on_black else "w"), a.done())

    def blank(self, w, h):
        return self.save("vc_blank_%dx%d.png" % (w, h), Image.new("RGBA", (w, h), (0, 0, 0, 0)))

    def seg(self, group, i, n, text, w, h, on):
        """joined segmented control: shared 1px dividers, selected = lifted cell, amber text, amber underline"""
        a = Art(w, h)
        first, last = i == 0, i == n - 1
        corners = (first, last, last, first)
        a.rect(0, 0, w, h, 5, fill=CTRL_SEL if on else CTRL, corners=corners)
        a.rect(0, 0, w, h, 5, edge=CTRL_EDGE, corners=corners)
        if not first:
            a.line(0, 0, 0, h, CTRL_EDGE)
        if on:
            a.rect(8, h - 4, w - 8, h - 2, 1, fill=ACCENT)
        size = 13 if w >= 60 else 12
        a.text_center(0, 0, w, h - 1, text, size, ACCENT if on else TEXT_2, "Medium" if on else "Regular")
        return self.save("vc_seg_%s_%d_%s.png" % (group, i, "on" if on else "off"), a.done())

    def chevron(self, nxt):
        a = Art(36, 36)
        pts = [(16, 12), (21, 18), (16, 24)] if nxt else [(20, 12), (15, 18), (20, 24)]
        a.d.line([(x * SS, y * SS) for x, y in pts], fill=TEXT_2, width=int(1.8 * SS), joint="curve")
        return self.save("vc_chev_%s.png" % ("next" if nxt else "prev"), a.done())

    def chevron_pressed(self, nxt):
        a = Art(36, 36)
        a.rect(2, 2, 34, 34, 4, fill=CTRL_SEL)
        pts = [(16, 12), (21, 18), (16, 24)] if nxt else [(20, 12), (15, 18), (20, 24)]
        a.d.line([(x * SS, y * SS) for x, y in pts], fill=ACCENT, width=int(1.8 * SS), joint="curve")
        return self.save("vc_chev_%s_on.png" % ("next" if nxt else "prev"), a.done())

    def switch(self, on):
        w, h = 44, 24
        a = Art(w, h)
        a.rect(0, 0, w, h, 12, fill=ACCENT if on else CTRL, edge=None if on else CTRL_EDGE)
        cx = w - 12 if on else 12
        a.d.ellipse(a.s(cx - 8, 4, cx + 8, 20), fill=INK_ON_ACCENT if on else "#6c7079")
        return self.save("vc_switch_%s.png" % ("on" if on else "off"), a.done())

    def button(self, name, text, w, h, on):
        a = Art(w, h)
        a.rect(0, 0, w, h, 5, fill=ACCENT if on else CTRL, edge=ACCENT if on else CTRL_EDGE)
        a.text_center(0, 0, w, h, text, 13, INK_ON_ACCENT if on else TEXT, "Medium")
        return self.save("vc_btn_%s_%s.png" % (name, "on" if on else "off"), a.done())

    def cell(self, row, on, w, h, colour):
        a = Art(w, h)
        if on:
            a.rect(0, 0, w, h, 3, fill=colour)
        else:
            a.rect(0, 0, w, h, 3, fill=CTRL, edge=CTRL_EDGE)
        return self.save("vc_cell_%d_%s.png" % (row, "on" if on else "off"), a.done())


class Background:
    """Full-page art: header, panels, field frames and labels; live text sits on top."""

    def __init__(self, page_title):
        self.a = Art(W, H, bg=BG)
        a = self.a
        a.rect(0, 0, W, 56, 0, fill=HEADER)
        a.line(0, 56, W, 56, HAIRLINE)
        for k, wbar in enumerate((18, 13, 8)):  # logo mark: a chord stack
            a.rect(24, 19 + k * 7, 24 + wbar, 23 + k * 7, 1.5, fill=ACCENT)
        a.text(52, 28, "VELVET CHORDS", 14, TEXT, "Medium", anchor="lm", tracking=2.2)
        a.line(212, 18, 212, 38, HAIRLINE)
        a.text(226, 28, page_title.upper(), 11, ACCENT, "Medium", anchor="lm", tracking=1.6)

    @property
    def d(self):
        return self.a.d

    def panel(self, box, title=None):
        x0, y0, x1, y1 = box
        self.a.rect(x0, y0, x1, y1, 6, fill=SURFACE, edge=HAIRLINE)
        if title:
            self.a.label(x0 + 16, y0 + 12, title)

    def field(self, x, y, w, h):
        self.a.rect(x, y, x + w, y + h, 5, fill=FIELD, edge=FIELD_EDGE)

    def caption(self, x, y, txt):
        self.a.label(x, y, txt)

    def text(self, *args, **kw):
        self.a.text(*args, **kw)

    @property
    def im(self):
        return self.a.done().convert("RGB")


# ---------------------------------------------------------------- TUI.json building blocks
def remap(pairs):
    return {"version": 1, "map": [{"key": k, "value": "Parameter %d" % v} for k, v in pairs]}


def bounds(x, y, w, h, focus="No", visible="Always", invalid="Show", inval=None):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": invalid, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": "%d %d %d %d" % (x, y, w, h), "additionalInvalidatingHandles": inval or []}


def action(on, handler, overlay=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": overlay, "handle remapping": {"version": 1, "map": []}}


A_QLINK = action("Mouse Down", "Q-Link")
A_OVERLAY_DBL = action("Double Click", "Show Overlay", "knob overlay")
A_OVERLAY_ENTER = action("Enter Pressed", "Show Overlay", "knob overlay")
A_TOGGLE_ENTER = action("Enter Pressed", "Toggle Switch")
A_TOGGLE_DOWN = action("Mouse Down", "Toggle Switch")


def sub(name, ctype, data, b):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": ctype, "data": data},
            "handle remapping": {"version": 1, "map": []}, "bounds": b}


def focus_sub(w, h):
    return sub("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": argb(ROSE),
                                  "backgroundInset": 2.0, "outlineThickness": 2.0}, bounds(0, 0, w, h, visible="WhenFocussed"))


def label_sub(name, handle, x, y, w, h, size, colour, just="horizontallyCentred verticallyCentred"):
    return sub(name, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": LIVE_FONT, "style": "SemiBold",
               "height": float(size)}, "colour": argb(colour), "justification": just, "case": "Original"},
               "type": "Value", "handleName": handle}, bounds(x, y, w, h))


def button_sub(on, off, bid, n, w, h, x=0, y=0):
    return sub("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": bid, "numButtonsInGroup": n,
                                    "handleName": "Data", "gestureBehaviour": "Instant"}, bounds(x, y, w, h))


def definition(actions, comps, bgcolour="0", ignore=False):
    return {"version": 4, "actions": actions,
            "backgroundData": {"version": 1, "focussed": {"version": 1, "colour": bgcolour, "image": ""},
                               "unfocussed": {"version": 1, "colour": bgcolour, "image": ""}},
            "ignoreMousePresses": ignore, "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True,
            "componentsData": comps}


STEP_ROWS = [  # (step type index in the plugin, label, colour when set)
    (2, "Accent", ACCENT),
    (1, "Chord", "#b9832f"),
    (5, "Upper acc", "#6fb1db"),
    (4, "Upper", "#3f7fa8"),
    (3, "Bass", "#8f74d6"),
    (6, "Tie", "#5a5f69"),
    (0, "Rest", "#34373e"),
]

CH = 36  # standard control height


class Skin:
    def __init__(self, params, outdir):
        self.P = params
        self.img = Images(outdir)
        self.defs = {}
        self.pages = []

    def p(self, name):
        if name not in self.P:
            raise KeyError("plugin has no parameter %r" % name)
        return self.P[name]

    def define(self, key, value):
        if key not in self.defs:
            self.defs[key] = value
        return key

    @staticmethod
    def place(deftype, name, x, y, w, h, pairs, focus="No", inval=None):
        return {"version": 2, "componentData": {"version": 1, "name": name, "type": deftype, "data": {"version": 1, "handleName": "Data"}},
                "handle remapping": remap(pairs), "bounds": bounds(x, y, w, h, focus=focus, invalid="Hide", inval=inval)}

    # ---- widgets
    def value_field(self, comps, bg, param, x, y, w, h=CH, size=18, colour=TEXT, editable=True, caption=None, box=True):
        if box:
            bg.field(x, y, w, h)
        if caption:
            bg.caption(x + 1, y - 17, caption)
        key = "vcField_%dx%d_%d_%s_%s" % (w, h, size, colour.lstrip("#"), "e" if editable else "r")
        comps_def = ([focus_sub(w, h)] if editable else []) + [label_sub("Value", "Data", 10, 0, w - 20, h, size, colour)]
        self.define(key, definition([A_QLINK, A_OVERLAY_DBL, A_OVERLAY_ENTER] if editable else [], comps_def, ignore=not editable))
        comps.append(self.place(key, caption or param, x, y, w, h, [("Data", self.p(param))], focus="Yes" if editable else "No"))

    def readout(self, comps, bg, param, x, y, w, h=CH, size=16, colour=TEXT_2, caption=None):
        self.value_field(comps, bg, param, x, y, w, h, size=size, colour=colour, editable=False, caption=caption)

    def stepper(self, comps, bg, param, prev, nxt, x, y, w, caption=None, h=CH):
        """one framed field with chevrons at both ends"""
        bg.field(x, y, w, h)
        bg.a.line(x + h, y + 6, x + h, y + h - 6, FIELD_EDGE)
        bg.a.line(x + w - h, y + 6, x + w - h, y + h - 6, FIELD_EDGE)
        for is_next, px, trig in ((False, x, prev), (True, x + w - h, nxt)):
            off, on = self.img.chevron(is_next), self.img.chevron_pressed(is_next)
            key = self.define("vcChev_%s" % ("next" if is_next else "prev"), definition([A_TOGGLE_ENTER], [button_sub(on, off, 1, 1, h, h)]))
            comps.append(self.place(key, "next" if is_next else "prev", px, y, h, h, [("Data", self.p(trig))]))
        self.value_field(comps, bg, param, x + h, y, w - 2 * h, h, size=18, box=False)
        if caption:
            bg.caption(x + 1, y - 17, caption)

    def segments(self, comps, bg, group, param, labels, x, y, w, h=CH, caption=None, ids=None, ntotal=None):
        """joined segmented control; ids/ntotal let one parameter's options span several rows"""
        if caption:
            bg.caption(x + 1, y - 17, caption)
        n = len(labels)
        for i, t in enumerate(labels):
            bid = ids[i] if ids else i
            on = self.img.seg(group, i, n, t, w, h, True)
            off = self.img.seg(group, i, n, t, w, h, False)
            key = self.define("vcSeg_%s_%d" % (group, i), definition([A_QLINK], [button_sub(on, off, bid, ntotal or n, w, h)]))
            comps.append(self.place(key, "%s %s" % (caption or group, t), x + i * w, y, w, h,
                                    [("Data", self.p(param))], focus="Yes" if i == 0 else "No"))

    def switch(self, comps, bg, param, x, y, caption=None):
        on, off = self.img.switch(True), self.img.switch(False)
        key = self.define("vcSwitch", definition([A_QLINK, A_TOGGLE_ENTER], [focus_sub(44, 24), button_sub(on, off, 1, 1, 44, 24)]))
        if caption:
            bg.caption(x + 1, y - 17, caption)
        comps.append(self.place(key, caption or param, x, y, 44, 24, [("Data", self.p(param))], focus="Yes"))

    def action_button(self, comps, bg, name, text, param, x, y, w=188, h=CH):
        on, off = self.img.button(name, text, w, h, True), self.img.button(name, text, w, h, False)
        key = self.define("vcBtn_%s" % name, definition([A_TOGGLE_ENTER], [button_sub(on, off, 1, 1, w, h)]))
        comps.append(self.place(key, text, x, y, w, h, [("Data", self.p(param))]))

    def pad_grid(self, comps, x0, y0, w=146, h=105, gap=8):
        """16 chord tiles laid out like the MPC's pads: 4x4, pad 1 bottom-left, pad 16 top-right"""
        for k in range(16):
            on, off = self.img.pad(k + 1, True, w, h), self.img.pad(k + 1, False, w, h)
            key = self.define("vcPad4_%d" % (k + 1), definition([A_QLINK], [
                button_sub(on, off, k + 1, 17, w, h),
                label_sub("Chord", "Chord", 6, 24, w - 12, 38, 24, TEXT),
                label_sub("Function", "Function", 6, 62, w - 12, 22, 13, TEXT_2),
            ]))
            col, row = k % 4, 3 - k // 4
            x = x0 + col * (w + gap)
            y = y0 + row * (h + gap)
            comps.append(self.place(key, "Pad %d" % (k + 1), x, y, w, h,
                                    [("Data", self.p("Screen pad")), ("Chord", self.p("Pad %d chord" % (k + 1))),
                                     ("Function", self.p("Pad %d function" % (k + 1)))]))

    def keyboard(self, comps, param, x0, y0, ww=56, wh=100, bw=34, bh=60, dots=False):
        """one-octave keyboard; each key is a button in a 12-way group bound to param"""
        whites = [0, 2, 4, 5, 7, 9, 11]
        pos = {}
        for i, pc in enumerate(whites):
            pos[pc] = (x0 + i * ww, y0, ww, wh)
        for pc, left in ((1, 0), (3, 2), (6, 5), (8, 7), (10, 9)):
            pos[pc] = (pos[left][0] + ww - bw // 2, y0, bw, bh)
        order = whites + [1, 3, 6, 8, 10]  # black keys last, on top
        for pc in order:
            x, y, w, h = pos[pc]
            on, off = self.img.key(pc, True, w, h), self.img.key(pc, False, w, h)
            key = self.define("vcKey_%d_%dx%d" % (pc, w, h), definition([A_QLINK], [button_sub(on, off, pc, 12, w, h)]))
            comps.append(self.place(key, "Key %d" % pc, x, y, w, h, [("Data", self.p(param))]))
        if dots:
            names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
            blank = self.img.blank(14, 14)
            for pc in order:
                black = pc in (1, 3, 6, 8, 10)
                im = self.img.dot(black)
                key = self.define("vcDot_%s" % ("b" if black else "w"), definition([], [button_sub(im, blank, 1, 1, 14, 14)], ignore=True))
                x, y, w, h = pos[pc]
                comps.append(self.place(key, "in scale %s" % names[pc], x + (w - 14) // 2, y + h - 20, 14, 14,
                                        [("Data", self.p("Scale has %s" % names[pc]))]))

    def step_matrix(self, comps, bg, x0, y0, cw=65, ch=24, gapx=5, gapy=4):
        for g in range(4):  # quiet shading behind every beat (4 steps)
            gx = x0 + g * 4 * (cw + gapx) - 4
            bg.a.rect(gx, y0 - 30, gx + 4 * cw + 3 * gapx + 8, y0 + 7 * (ch + gapy) + 2, 5, fill="#1a1b1f" if g % 2 == 0 else SURFACE)
        for r, (_, label, colour) in enumerate(STEP_ROWS):
            y = y0 + r * (ch + gapy)
            bg.a.rect(x0 - 104, y + 9, x0 - 98, y + 15, 1.5, fill=colour)
            bg.a.text(x0 - 90, y + ch / 2, label.upper(), 10, LABEL, "Medium", anchor="lm", tracking=1.0)
        for k in range(16):
            x = x0 + k * (cw + gapx)
            bg.a.text(x + cw / 2, y0 - 16, str(k + 1), 11, TEXT if k % 4 == 0 else LABEL, "Medium", anchor="mm")
            for r, (state, label, colour) in enumerate(STEP_ROWS):
                on, off = self.img.cell(r, True, cw, ch, colour), self.img.cell(r, False, cw, ch, colour)
                key = self.define("vcCell_%d" % r, definition([A_QLINK], [button_sub(on, off, state, 7, cw, ch)]))
                comps.append(self.place(key, "Step %d %s" % (k + 1, label), x, y0 + r * (ch + gapy), cw, ch,
                                        [("Data", self.p("Step %d" % (k + 1)))], focus="Yes" if r == 1 else "No"))

    # ---- pages
    def page(self, tab_name, fn, comps, bg_name, bg):
        img = self.img.save(bg_name, bg.im)
        background = sub("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": img}, bounds(0, 0, W, H))
        key = "%s|%s" % (tab_name.upper(), tab_name)
        self.define(key, definition([], [background] + comps, bgcolour=argb(BG)))
        self.pages.append({"version": 3, "tabName": tab_name, "fnKeyIndex": fn, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
                           "componentName": key, "initialSize": "0 0 %d %d" % (W, H), "scale": 1.0})

    def header_banks(self, c, bg, group):
        bg.a.text(1066, 28, "BANK", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.segments(c, bg, group, "Screen bank", ["A", "B", "C", "D"], 1076, 12, 45, 32)

    def build(self):
        voicings = ["Bass+upper", "Close", "Drop 2", "Spread", "Upper"]
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        # ---------- Play
        bg = Background("Play")
        c = []
        self.segments(c, bg, "mode", "Mode", ["Song", "Scale", "R&B kit", "Types", "Custom"], 456, 12, 104, 32)
        self.header_banks(c, bg, "bank")
        bg.panel((12, 64, 1268, 144))
        self.stepper(c, bg, "Song", "Song prev", "Song next", 28, 96, 548, "Song")
        self.stepper(c, bg, "Section", "Section prev", "Section next", 592, 96, 300, "Section")
        self.readout(c, bg, "Info", 908, 96, 344, size=14, caption="Song data")
        bg.panel((12, 152, 632, 620))
        self.pad_grid(c, 20, 162)
        bg.panel((640, 152, 1268, 620))
        bg.caption(656, 166, "Key")
        bg.a.text(1252, 166, "DOTS MARK THE SCALE", 9.5, "#4d5159", "Medium", anchor="ra", tracking=1.0)
        self.keyboard(c, "Key", 656, 186, 56, 100, 34, 60, dots=True)
        self.stepper(c, bg, "Scale", "Scale prev", "Scale next", 656, 322, 596, "Scale")
        self.segments(c, bg, "smart", "Smart pads", ["Off", "Pads 9-16", "Follow"], 656, 390, 104, caption="Smart Scale pads")
        self.segments(c, bg, "smartn", "Smart notes", ["Chord", "Scale", "Bass"], 976, 390, 92, caption="Smart notes")
        self.segments(c, bg, "voicing1", "Voicing", voicings, 656, 458, 119, caption="Voicing")
        self.readout(c, bg, "Now playing", 656, 526, 596, 44, size=17, colour=ACCENT, caption="Now playing")
        self.page("Play", 0, c, "vc_bg_play.png", bg)

        # ---------- Perform
        bg = Background("Perform")
        c = []
        L, R = 28, 664
        rows = [100, 184, 268, 352, 436, 520]
        bg.panel((12, 64, 632, 620))
        bg.panel((648, 64, 1268, 620))
        # two keyboards of the same size (this is where the built-in instruments used to be):
        # left = chords, right = notes that fit; the black keys carry their own jobs
        KW, KH, BW, BH, KY = 84, 150, 52, 92, 96
        bg.caption(L + 1, KY - 17, "Left hand   chords")
        bg.caption(R + 1, KY - 17, "Right hand   notes that fit the chord")
        black_at = [0, 1, 3, 4, 5]                                  # the white key each black key sits after
        for k in range(7):                                          # left white keys: pads 1-7 of the bank on screen
            on, off = self.img.bigkey(k + 1, True, KW, KH), self.img.bigkey(k + 1, False, KW, KH)
            key = self.define("vcBigKey_%d" % (k + 1), definition([A_QLINK], [
                button_sub(on, off, k + 1, 17, KW, KH),
                label_sub("Chord", "Chord", 3, 94, KW - 6, 24, 17, INK_ON_ACCENT),
                label_sub("Function", "Function", 3, 116, KW - 6, 14, 10.5, "#4a4c50"),
            ]))
            c.append(self.place(key, "Chord key %d" % (k + 1), L + k * KW, KY, KW, KH,
                                [("Data", self.p("Screen pad")), ("Chord", self.p("Pad %d chord" % (k + 1))),
                                 ("Function", self.p("Pad %d function" % (k + 1)))]))
        left_black = [("keydn", ["KEY", "DOWN"], "Key down"), ("keyup", ["KEY", "UP"], "Key up"),
                      ("scprev", ["SCALE", "PREV"], "Scale prev"), ("scnext", ["SCALE", "NEXT"], "Scale next"),
                      ("banknext", ["NEXT", "BANK"], "Bank next")]
        for (name, lines, param), wk in zip(left_black, black_at):  # left black keys: shifters you can also tap
            on, off = self.img.bigblack(name, lines, BW, BH, True), self.img.bigblack(name, lines, BW, BH, False)
            key = self.define("vcBigBlack_%s" % name, definition([A_TOGGLE_ENTER], [button_sub(on, off, 1, 1, BW, BH)]))
            c.append(self.place(key, " ".join(lines), L + (wk + 1) * KW - BW // 2, KY, BW, BH, [("Data", self.p(param))]))
        for k in range(7):                                          # right white keys: the note each one plays now
            bg.a.rect(R + k * KW + 1, KY, R + (k + 1) * KW - 1, KY + KH, 4, fill=KEY_WHITE, edge=KEY_WHITE_EDGE,
                      corners=(False, False, True, True))
            self.value_field(c, bg, "Smart key %d" % (k + 1), R + k * KW + 3, KY + 100, KW - 6, 30, size=18,
                             colour=INK_ON_ACCENT, editable=False, box=False)
        for k, wk in enumerate(black_at):                           # right black keys: tap one to pick it; it shows its pattern
            on, off = self.img.bigblack_sel(True, BW, BH), self.img.bigblack_sel(False, BW, BH)
            key = self.define("vcGenKey_%d" % k, definition([A_QLINK], [
                button_sub(on, off, k, 5, BW, BH),
                label_sub("Pattern", "Pattern", 1, BH - 40, BW - 2, 28, 11, "#d6d8dc"),
            ]))
            c.append(self.place(key, "Pattern key %d" % (k + 1), R + (wk + 1) * KW - BW // 2, KY, BW, BH,
                                [("Data", self.p("Gen key")), ("Pattern", self.p("G%d pattern" % (k + 1)))]))
        r0, r1, r2, r3, r4 = 270, 338, 406, 474, 542
        self.segments(c, bg, "kbd", "Keyboard", ["Pads only", "Split keyboard"], L, r0, 120, caption="Play from")
        self.value_field(c, bg, "Split point", L + 256, r0, 120, caption="Split at")
        self.value_field(c, bg, "Screen bank", L + 392, r0, 90, caption="Bank")
        self.value_field(c, bg, "Key", L + 498, r0, 90, caption="Key")
        self.value_field(c, bg, "Velocity", L, r1, 150, caption="Velocity")
        self.action_button(c, bg, "export", "Export MIDI", "Export MIDI", L + 162, r1, w=130)
        self.readout(c, bg, "Export MIDI", L + 304, r1, 284, size=14)
        self.value_field(c, bg, "Strum", L, r2, 188, caption="Strum")
        self.segments(c, bg, "strumdir", "Strum dir", ["Up", "Down", "Alternate"], L + 204, r2, 128, caption="Strum direction")
        self.value_field(c, bg, "Arp", L, r3, 150, caption="Arpeggiator")
        self.segments(c, bg, "rate", "Arp rate", ["1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"], L + 162, r3, 71, caption="Arp rate")
        self.value_field(c, bg, "Pad 1 note", L, r4, 150, caption="Pad 1 note")
        self.action_button(c, bg, "learn", "Learn pad 1", "Learn pad 1", L + 162, r4, w=200)
        self.action_button(c, bg, "learnall", "Learn all 16 pads", "Learn all pads", L + 374, r4, w=214)
        self.segments(c, bg, "smartn2", "Smart notes", ["Chord tones", "Scale", "Bass"], R, r0, 100, caption="White keys play")
        self.value_field(c, bg, "Smart octave", R + 316, r0, 120, caption="Octave")
        bg.a.text(R + 588, r0 + 10, "TAP A BLACK KEY", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        bg.a.text(R + 588, r0 + 26, "TO EDIT ITS PATTERN", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.value_field(c, bg, "Gen pattern", R, r1, 170, caption="Picked key pattern")
        self.value_field(c, bg, "Gen rate", R + 182, r1, 90, caption="Rate")
        self.value_field(c, bg, "Gen range", R + 284, r1, 90, caption="Range")
        self.value_field(c, bg, "Gen tones", R + 386, r1, 110, caption="Tones")
        self.value_field(c, bg, "Gen gate", R + 508, r1, 80, caption="Length")
        self.segments(c, bg, "voicing2", "Voicing", voicings, R, r2, 117, caption="Voicing")
        self.segments(c, bg, "inv", "Inversion", ["Root", "1st", "2nd", "3rd"], R, r3, 82, caption="Inversion")
        self.segments(c, bg, "oct", "Octave", ["-2", "-1", "0", "+1", "+2"], R + 338, r3, 50, caption="Chord octave")
        self.value_field(c, bg, "Transpose", R, r4, 188, caption="Transpose (song)")
        self.switch(c, bg, "Voice lead", R + 204, r4 + 6, "Voice leading")
        self.value_field(c, bg, "MIDI out", R + 336, r4, 252, caption="MIDI out")
        self.page("Perform", 1, c, "vc_bg_perform.png", bg)

        # ---------- Edit
        bg = Background("Edit pads")
        c = []
        bg.a.text(466, 28, "PAD", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.stepper(c, bg, "Edit pad", "Edit pad prev", "Edit pad next", 476, 10, 180)
        bg.a.text(866, 28, "TAP SELECTS", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.switch(c, bg, "Edit follows pad", 876, 16)
        self.header_banks(c, bg, "bank3")
        bg.panel((12, 64, 632, 620))
        self.pad_grid(c, 20, 110)
        bg.a.text(28, 84, "TAP A PAD TO EDIT IT", 10.5, LABEL, "Medium", tracking=1.3)
        bg.panel((640, 64, 1268, 620))
        bg.caption(656, 78, "Root")
        self.keyboard(c, "Edit root", 656, 98, 48, 86, 30, 52)
        self.segments(c, bg, "bass", "Edit bass", ["Root"] + notes, 656, 222, 46, caption="Bass note")
        self.stepper(c, bg, "Edit type", "Edit type prev", "Edit type next", 656, 296, 596, "Chord type")
        self.segments(c, bg, "einv", "Edit inversion", ["Root", "1st", "2nd", "3rd"], 656, 370, 84, caption="Inversion")
        self.segments(c, bg, "eoct", "Edit octave", ["-2", "-1", "0", "+1", "+2"], 1012, 370, 48, caption="Octave")
        self.readout(c, bg, "Now playing", 656, 444, 596, 40, size=15, colour=ACCENT, caption="Now playing")
        self.action_button(c, bg, "copy", "Copy layout to Custom", "Copy to Custom", 656, 516, w=596)
        self.page("Edit", 2, c, "vc_bg_edit.png", bg)

        # ---------- Pattern
        bg = Background("Pattern")
        c = []
        bg.panel((12, 64, 1268, 144))
        self.stepper(c, bg, "Pattern", "Pattern prev", "Pattern next", 28, 96, 420, "Pattern")
        self.segments(c, bg, "prate", "Pattern rate", ["1/8", "1/8T", "1/16", "1/16T", "1/32"], 492, 96, 78, caption="Step length")
        self.segments(c, bg, "psync", "Pattern sync", ["Free", "Follow MPC"], 912, 96, 170, caption="Timing")
        bg.panel((12, 152, 1268, 408))
        self.step_matrix(c, bg, 132, 196)
        bg.panel((12, 416, 1268, 620))
        r1, r2 = 450, 542
        self.value_field(c, bg, "Swing", 28, r1, 150, caption="Swing")
        self.value_field(c, bg, "Gate", 190, r1, 150, caption="Note length")
        self.value_field(c, bg, "Keyboard", 360, r1, 226, caption="Play from")
        self.value_field(c, bg, "Split point", 598, r1, 226, caption="Split at")
        self.value_field(c, bg, "MIDI channel", 844, r1, 120, caption="Out channel")
        self.readout(c, bg, "Now playing", 980, r1, 272, size=13, colour=ACCENT, caption="Now playing")
        self.segments(c, bg, "mout", "MIDI out", ["Virtual port", "To MPC", "Both"], 28, r2, 200, caption="Send chords as MIDI to")
        self.readout(c, bg, "MIDI port", 644, r2, 608, size=14, caption="Virtual port: Velvet Chords Out")
        self.page("Pattern", 3, c, "vc_bg_pattern.png", bg)

        # ---------- Tools: hold, repeat, melody, key sync, MIDI import
        bg = Background("Tools")
        c = []
        L, R = 28, 664
        bg.panel((12, 64, 632, 620))
        bg.a.label(L, 76, "Playing")
        self.switch(c, bg, "Hold", L, 116, "Hold: chords keep playing")
        bg.a.text(L + 60, 128, "PRESS ANOTHER PAD TO CHANGE, SAME PAD TO STOP", 9.5, "#4d5159", "Medium", anchor="lm", tracking=1.0)
        self.segments(c, bg, "rep", "Repeat", ["Off", "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"], L, 196, 84, caption="Repeat (in time with the MPC)")
        self.segments(c, bg, "mel", "Melody", ["Off", "Simple", "Busy"], L, 280, 196, caption="Melody generator")
        self.segments(c, bg, "melr", "Melody rate", ["1/8", "1/8T", "1/16"], L, 364, 196, caption="Melody rate")
        self.switch(c, bg, "Key sync", L, 448, "Key and scale: follow another copy")
        self.readout(c, bg, "Now playing", L, 524, 588, 44, size=16, colour=ACCENT, caption="Now playing")
        bg.panel((648, 64, 1268, 620))
        bg.a.label(R, 76, "MIDI import")
        self.stepper(c, bg, "Import file", "Import prev", "Import next", R, 116, 588, "File (Velvet Chords/Import)")
        self.action_button(c, bg, "imp", "Load chords", "Import load", R, 184, w=280)
        self.segments(c, bg, "imppads", "Pads play", ["Layout", "Imported"], R + 296, 184, 146, caption="")
        bg.caption(R + 297, 167, "Pads play")
        self.readout(c, bg, "Import status", R, 268, 588, 44, size=15, caption="Status")
        for i, line in enumerate([
                "1. Copy .mid files into the Velvet Chords/Import folder",
                "   on the MPC's internal drive.",
                "2. Pick a file and press Load chords.",
                "3. Its chords appear on the pads, in order, with the",
                "   file's exact notes. Copy to Custom (Edit page) to edit."]):
            bg.a.text(R, 344 + i * 26, line, 12.5, TEXT_2, "Regular")
        self.page("Tools", 4, c, "vc_bg_tools.png", bg)

    def tui(self):
        return {"pageData": {"version": 1, "componentDefinitions": {"version": 2, "importFiles": [
            "/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
            "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
            "localComponentDefinitions": [{"key": k, "value": v} for k, v in self.defs.items()]},
            "info": {"version": 1, "type": "CompleteDescription"}, "tabs": self.pages}}

    def qlinks(self):
        def m(names):
            names = (names + [None] * 16)[:16]
            return {"Q-Link %d" % (i + 1): (self.p(n) if n else -1) for i, n in enumerate(names)}
        play = ["Mode", "Song", "Section", "Screen bank", "Key", "Scale", "Transpose", "Voicing",
                "Inversion", "Octave", "Voice lead", "Keyboard", "Smart pads", "Smart notes", "Smart octave", "Split point"]
        perform = ["Keyboard", "Split point", "Smart notes", "Smart octave", "Gen key", "Gen pattern", "Gen rate", "Gen range",
                   "Gen tones", "Gen gate", "Velocity", "Strum", "Arp", "Arp rate", "Voicing", "MIDI out"]
        edit = ["Edit pad", "Edit root", "Edit type", "Edit bass", "Edit inversion", "Edit octave", "Edit follows pad",
                "Screen bank", "Mode", "Voicing", "Keyboard", "Split point"]
        pattern = ["Step %d" % (k + 1) for k in range(16)]
        tools = ["Hold", "Repeat", "Melody", "Melody rate", "Key sync", "Import file", "Pads play", "Smart pads",
                 "Smart notes", "Smart octave", "Pattern", "Strum", "Keyboard", "Split point"]
        tabs = [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": m(x)} for i, x in enumerate([play, perform, edit, pattern, tools])]
        return {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
                "Screen Mode Q-Links": {"version": 4, "map": tabs}, "Program Mode Q-Links": m(play)}


def main():
    so, lister, out = sys.argv[1], sys.argv[2], sys.argv[3]
    params = load_params(so, lister)
    skin_dir = os.path.join(out, "Velvet Chords - VST - Velvet Chords")
    os.makedirs(skin_dir, exist_ok=True)
    s = Skin(params, skin_dir)
    s.build()
    json.dump(s.tui(), open(os.path.join(skin_dir, "TUI.json"), "w"), indent=4)
    q = s.qlinks()
    for name in ("Q-Links.json", "Q-Links - 8by1.json"):
        json.dump(q, open(os.path.join(skin_dir, name), "w"), indent=4)
    print("skin: %s (%d definitions, %d pages, %d images)" % (skin_dir, len(s.defs), len(s.pages), len(s.img.made)))


if __name__ == "__main__":
    main()
